import React from 'react';
import { Sparkles, CheckCircle, Lightbulb, ChevronRight, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AISuggestion } from '../types';

interface AISidebarProps {
  suggestion: AISuggestion | null;
  onClose: () => void;
  onApply: (code: string) => void;
  isGenerating: boolean;
}

export const AISidebar: React.FC<AISidebarProps> = ({ suggestion, onClose, onApply, isGenerating }) => {
  return (
    <AnimatePresence>
      <motion.div 
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className="w-80 bg-[#161922] border-l border-slate-800 flex flex-col shadow-2xl z-10"
      >
        <div className="h-12 border-b border-slate-800 flex items-center justify-between px-4 bg-[#0f1117]">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-indigo-400">
            <Sparkles className="w-4 h-4" />
            <span>AI Inspector</span>
          </div>
          <button 
            onClick={onClose}
            className="p-1 hover:bg-slate-800 rounded transition-colors text-slate-500 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-5 space-y-8">
          {isGenerating ? (
            <div className="flex flex-col items-center justify-center h-full gap-4 opacity-50">
              <div className="w-8 h-8 border-2 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin"></div>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Processing Logic</p>
            </div>
          ) : !suggestion ? (
            <div className="flex flex-col items-center justify-center h-64 text-slate-600 gap-3 text-center px-4">
              <Lightbulb className="w-10 h-10 opacity-20" />
              <p className="text-xs font-medium leading-relaxed">Launch <span className="text-indigo-400 font-bold">AI Assist</span> to optimize performance and catch edge cases.</p>
            </div>
          ) : (
            <>
              <section>
                <h3 className="text-[10px] uppercase tracking-[0.2em] font-black text-slate-500 mb-4 flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-indigo-500"></div>
                  Optimization Tips
                </h3>
                <div className="space-y-3">
                  {suggestion.suggestions.map((tip, i) => (
                    <motion.div 
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.1 }}
                      key={i} 
                      className="p-4 bg-[#1a1d27] border border-slate-800 rounded text-xs leading-relaxed text-slate-400 relative group"
                    >
                      <div className="absolute left-0 top-0 bottom-0 w-1 bg-indigo-500/20 group-hover:bg-indigo-500 transition-colors"></div>
                      {tip}
                    </motion.div>
                  ))}
                </div>
              </section>

              <section className="mt-8">
                <h3 className="text-[10px] uppercase tracking-[0.2em] font-black text-slate-500 mb-4 flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
                  Refined Version
                </h3>
                <div className="p-4 bg-[#1a1d27] border border-slate-800 rounded relative group overflow-hidden">
                  <div className="absolute top-0 right-0 p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <CheckCircle className="w-4 h-4 text-emerald-500" />
                  </div>
                  <pre className="text-[11px] font-mono text-slate-300 overflow-x-auto pb-4 border-b border-slate-800/50 mb-4">
                    {suggestion.improvedCode.length > 300 
                      ? suggestion.improvedCode.slice(0, 300) + '\n\n# ...' 
                      : suggestion.improvedCode}
                  </pre>
                  <button
                    onClick={() => onApply(suggestion.improvedCode)}
                    className="w-full flex items-center justify-center gap-2 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-black uppercase tracking-[0.2em] rounded transition-all shadow-lg shadow-indigo-500/20"
                  >
                    Apply Update
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </section>
            </>
          )}
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
