import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Package, Search, Plus, Trash2, Loader2, CheckCircle2, AlertCircle, X, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PythonPackage } from '../types';

interface PackageManagerProps {
  onClose: () => void;
}

export const PackageManager: React.FC<PackageManagerProps> = ({ onClose }) => {
  const [packages, setPackages] = useState<PythonPackage[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isInstalling, setIsInstalling] = useState(false);
  const [status, setStatus] = useState<{ type: 'success' | 'error', message: string } | null>(null);

  const fetchPackages = async () => {
    setIsLoading(true);
    try {
      const res = await axios.get('/api/packages');
      setPackages(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchPackages();
  }, []);

  const handleInstall = async () => {
    if (!searchTerm.trim()) return;
    setIsInstalling(true);
    setStatus(null);
    try {
      const res = await axios.post('/api/packages/install', { name: searchTerm });
      if (res.data.success) {
        setStatus({ type: 'success', message: `Successfully installed ${searchTerm}` });
        setSearchTerm('');
        fetchPackages();
      } else {
        setStatus({ type: 'error', message: res.data.stderr || 'Installation failed' });
      }
    } catch (err) {
      setStatus({ type: 'error', message: 'Failed to connect to server' });
    } finally {
      setIsInstalling(false);
    }
  };

  const handleUninstall = async (name: string) => {
    if (!confirm(`Uninstall ${name}?`)) return;
    try {
      const res = await axios.post('/api/packages/uninstall', { name });
      if (res.data.success) {
        setStatus({ type: 'success', message: `Uninstalled ${name}` });
        fetchPackages();
      } else {
        setStatus({ type: 'error', message: res.data.stderr || 'Uninstallation failed' });
      }
    } catch (err) {
      setStatus({ type: 'error', message: 'Failed to uninstall package' });
    }
  };

  const filteredPackages = packages.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        className="w-80 bg-[#161922] border-l border-slate-800 flex flex-col shadow-2xl z-20"
      >
        <div className="h-12 border-b border-slate-800 flex items-center justify-between px-4 bg-[#0f1117]">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.2em] text-indigo-400">
            <Package className="w-4 h-4" />
            <span>Package Manager</span>
          </div>
          <button 
            onClick={onClose}
            className="p-1 hover:bg-slate-800 rounded transition-colors text-slate-500 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 border-b border-slate-800 bg-[#1a1d27]">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-500" />
            <input 
              type="text" 
              placeholder="Search or install package..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleInstall()}
              className="w-full bg-[#0f1117] border border-slate-800 rounded py-2 pl-9 pr-4 text-xs text-slate-200 focus:outline-none focus:border-indigo-500/50 transition-all"
            />
            {searchTerm && (
              <button 
                onClick={handleInstall}
                disabled={isInstalling}
                className="absolute right-2 top-1.5 p-1 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-600/50 text-white rounded transition-all shadow-lg shadow-indigo-500/20"
                title="Install Package"
              >
                {isInstalling ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
              </button>
            )}
          </div>
          
          {status && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`mt-3 p-3 rounded text-[10px] flex items-start gap-2 border ${
                status.type === 'success' ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-400' : 'bg-rose-500/5 border-rose-500/20 text-rose-400'
              }`}
            >
              {status.type === 'success' ? <CheckCircle2 className="w-3.5 h-3.5 shrink-0" /> : <AlertCircle className="w-3.5 h-3.5 shrink-0" />}
              <span className="leading-relaxed">{status.message}</span>
            </motion.div>
          )}
        </div>

        <div className="flex-1 overflow-y-auto">
          <div className="p-4 uppercase text-[10px] font-bold text-slate-500 tracking-widest flex items-center justify-between">
            <span>Installed Dependencies</span>
            <span className="bg-slate-800 px-1.5 py-0.5 rounded text-[9px] text-slate-400">{packages.length}</span>
          </div>

          <div className="px-2 pb-4">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-20 gap-3 opacity-50">
                <Loader2 className="w-6 h-6 animate-spin text-indigo-500" />
                <span className="text-[10px] uppercase tracking-widest font-bold text-slate-600">Syncing Pip</span>
              </div>
            ) : filteredPackages.length === 0 ? (
              <div className="text-center py-12 text-slate-600">
                <Package className="w-8 h-8 mx-auto mb-3 opacity-20" />
                <p className="text-xs">No packages found</p>
              </div>
            ) : (
              filteredPackages.map((pkg) => (
                <div 
                  key={pkg.name}
                  className="group flex items-center justify-between px-3 py-2.5 hover:bg-[#1a1d27] rounded transition-all mb-1 border border-transparent hover:border-slate-800/50"
                >
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-slate-200 group-hover:text-indigo-400 transition-colors">{pkg.name}</span>
                    <span className="text-[10px] text-slate-500 font-mono">v{pkg.version}</span>
                  </div>
                  <button 
                    onClick={() => handleUninstall(pkg.name)}
                    className="p-1.5 opacity-0 group-hover:opacity-100 hover:bg-rose-500/10 text-slate-600 hover:text-rose-400 rounded transition-all"
                    title="Uninstall"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
        
        <div className="p-4 bg-[#0f1117] border-t border-slate-800 text-[10px] text-slate-600 italic">
          Packages are managed via pip3 in the current workspace environment.
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
