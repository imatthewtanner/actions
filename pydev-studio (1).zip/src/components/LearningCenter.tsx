import React from 'react';
import { BookOpen, GraduationCap, Code2, Lightbulb, X, ChevronRight, Hash } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface LearningCenterProps {
  onClose: () => void;
}

export const LearningCenter: React.FC<LearningCenterProps> = ({ onClose }) => {
  const sections = [
    {
      title: "Function Basics",
      icon: <Code2 className="w-4 h-4 text-indigo-400" />,
      content: [
        {
          heading: "Defining a Function",
          text: "Functions are defined using the 'def' keyword followed by the function name and parentheses.",
          code: "def greet(name):\n    return f'Hello, {name}!'"
        },
        {
          heading: "Return Statement",
          text: "The 'return' statement exits a function and optionally passes back an expression to the caller.",
          code: "def add(a, b):\n    return a + b"
        }
      ]
    },
    {
      title: "Advanced Concepts",
      icon: <GraduationCap className="w-4 h-4 text-emerald-400" />,
      content: [
        {
          heading: "Default Arguments",
          text: "You can provide default values for arguments, making them optional.",
          code: "def power(base, exp=2):\n    return base ** exp"
        },
        {
          heading: "Lambda Functions",
          text: "Small anonymous functions can be created with the 'lambda' keyword.",
          code: "square = lambda x: x * x"
        }
      ]
    },
    {
      title: "Pro Tips",
      icon: <Lightbulb className="w-4 h-4 text-amber-400" />,
      tips: [
        "Use descriptive names (snake_case) for your functions.",
        "Keep functions focused on a single task (Single Responsibility Principle).",
        "Document your functions using docstrings (triple quotes).",
        "Avoid using global variables inside functions unless necessary.",
        "Always handle potential exceptions using try/except blocks."
      ]
    }
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="fixed inset-y-0 right-0 w-[400px] bg-[#0c0e14] border-l border-slate-800 shadow-2xl flex flex-col z-50"
    >
      <div className="h-14 border-b border-slate-800 flex items-center justify-between px-6 bg-[#161922]">
        <div className="flex items-center gap-3 text-indigo-400">
          <BookOpen className="w-5 h-5" />
          <span className="font-bold uppercase tracking-widest text-xs">Learning Lab</span>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-slate-800 rounded-full transition-colors text-slate-500">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-8">
        {sections.map((section, idx) => (
          <section key={idx}>
            <div className="flex items-center gap-2 mb-4">
              {section.icon}
              <h2 className="text-[10px] uppercase tracking-[0.2em] font-black text-slate-500">{section.title}</h2>
            </div>
            
            {section.content && (
              <div className="space-y-4">
                {section.content.map((item, i) => (
                  <div key={i} className="bg-[#1a1d27] border border-slate-800 rounded-lg p-4">
                    <h3 className="text-xs font-bold text-slate-200 mb-2">{item.heading}</h3>
                    <p className="text-[11px] text-slate-400 mb-3 leading-relaxed">{item.text}</p>
                    <div className="bg-[#0f1117] p-3 rounded font-mono text-[10px] text-indigo-300 border border-slate-800/50">
                      <pre>{item.code}</pre>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {section.tips && (
              <div className="space-y-2">
                {section.tips.map((tip, i) => (
                  <div key={i} className="flex items-start gap-3 p-3 bg-[#1a1d27]/50 border border-slate-800/50 rounded-lg group hover:border-amber-500/30 transition-colors">
                    <Hash className="w-3.5 h-3.5 text-slate-600 mt-0.5" />
                    <p className="text-[11px] text-slate-400 leading-relaxed group-hover:text-slate-300 transition-colors">{tip}</p>
                  </div>
                ))}
              </div>
            )}
          </section>
        ))}
      </div>

      <div className="p-4 bg-[#0f1117] border-t border-slate-800">
        <div className="p-4 bg-indigo-600/10 border border-indigo-500/20 rounded-xl">
          <p className="text-[10px] text-indigo-400 leading-relaxed font-medium">
            "The best way to learn is to build. Experiment with these concepts in the editor above!"
          </p>
        </div>
      </div>
    </motion.div>
  );
};
