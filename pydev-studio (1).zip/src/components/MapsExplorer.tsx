import React, { useState, useEffect, useRef } from 'react';
import { 
  APIProvider, 
  Map, 
  AdvancedMarker, 
  Pin, 
  InfoWindow, 
  useMap, 
  useMapsLibrary, 
  useAdvancedMarkerRef 
} from '@vis.gl/react-google-maps';
import { 
  MapPin, 
  Search, 
  Navigation, 
  Layers, 
  Compass, 
  X, 
  Loader2, 
  Copy, 
  Check, 
  Route as RouteIcon, 
  ExternalLink,
  Sparkles,
  Code
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface MapsExplorerProps {
  onClose: () => void;
  onInsertCode?: (code: string) => void;
}

const API_KEY =
  process.env.GOOGLE_MAPS_PLATFORM_KEY ||
  (import.meta as any).env?.VITE_GOOGLE_MAPS_PLATFORM_KEY ||
  (globalThis as any).GOOGLE_MAPS_PLATFORM_KEY ||
  '';

const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY';

// Internal Route Renderer Component using Routes API (New)
function RouteDisplay({ 
  origin, 
  destination,
  onRouteCalculated
}: {
  origin: google.maps.LatLngLiteral | null;
  destination: google.maps.LatLngLiteral | null;
  onRouteCalculated?: (info: { distance: string; duration: string }) => void;
}) {
  const map = useMap();
  const routesLib = useMapsLibrary('routes');
  const polylinesRef = useRef<google.maps.Polyline[]>([]);

  useEffect(() => {
    if (!routesLib || !map || !origin || !destination) {
      polylinesRef.current.forEach(p => p.setMap(null));
      polylinesRef.current = [];
      return;
    }

    polylinesRef.current.forEach(p => p.setMap(null));

    routesLib.Route.computeRoutes({
      origin,
      destination,
      travelMode: 'DRIVING',
      fields: ['path', 'distanceMeters', 'durationMillis', 'viewport'],
    }).then(({ routes }) => {
      if (routes?.[0]) {
        const newPolylines = routes[0].createPolylines();
        newPolylines.forEach(p => {
          p.setOptions({
            strokeColor: '#6366f1',
            strokeWeight: 5,
            strokeOpacity: 0.85
          });
          p.setMap(map);
        });
        polylinesRef.current = newPolylines;

        if (routes[0].viewport) {
          map.fitBounds(routes[0].viewport);
        }

        if (onRouteCalculated) {
          const distKm = routes[0].distanceMeters ? (routes[0].distanceMeters / 1000).toFixed(1) + ' km' : 'N/A';
          const durMin = routes[0].durationMillis ? Math.round(routes[0].durationMillis / 60000) + ' mins' : 'N/A';
          onRouteCalculated({ distance: distKm, duration: durMin });
        }
      }
    }).catch(err => {
      console.error('Route calculation error:', err);
    });

    return () => {
      polylinesRef.current.forEach(p => p.setMap(null));
    };
  }, [routesLib, map, origin, destination]);

  return null;
}

// Custom Marker with InfoWindow
interface PlaceMarkerProps {
  place: {
    id: string;
    title: string;
    location: google.maps.LatLngLiteral;
    address?: string;
  };
  isSelected: boolean;
  onSelect: () => void;
  onClose: () => void;
}

const PlaceMarker: React.FC<PlaceMarkerProps> = ({
  place,
  isSelected,
  onSelect,
  onClose
}) => {
  const [markerRef, marker] = useAdvancedMarkerRef();

  return (
    <>
      <AdvancedMarker 
        ref={markerRef} 
        position={place.location} 
        onClick={onSelect}
        title={place.title}
      >
        <Pin 
          background={isSelected ? "#f59e0b" : "#6366f1"} 
          glyphColor="#ffffff" 
          borderColor={isSelected ? "#b45309" : "#4338ca"} 
        />
      </AdvancedMarker>
      {isSelected && (
        <InfoWindow 
          anchor={marker} 
          onCloseClick={onClose}
        >
          <div className="p-2 min-w-[200px] text-slate-900">
            <h4 className="font-bold text-xs text-indigo-950 mb-1">{place.title}</h4>
            {place.address && (
              <p className="text-[10px] text-slate-600 mb-2 leading-relaxed">{place.address}</p>
            )}
            <div className="text-[9px] font-mono bg-slate-100 p-1.5 rounded text-slate-700">
              {place.location.lat.toFixed(5)}, {place.location.lng.toFixed(5)}
            </div>
          </div>
        </InfoWindow>
      )}
    </>
  );
}

// Inner Map Controller
function MapContent({
  searchQuery,
  onInsertCode,
  selectedLocation,
  setSelectedLocation
}: {
  searchQuery: string;
  onInsertCode?: (code: string) => void;
  selectedLocation: { lat: number; lng: number; title: string; address?: string } | null;
  setSelectedLocation: React.Dispatch<React.SetStateAction<{ lat: number; lng: number; title: string; address?: string } | null>>;
}) {
  const placesLib = useMapsLibrary('places');
  const map = useMap();
  const [places, setPlaces] = useState<Array<{
    id: string;
    title: string;
    location: google.maps.LatLngLiteral;
    address?: string;
  }>>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedPlaceId, setSelectedPlaceId] = useState<string | null>(null);

  // Route calculation states
  const [routeOrigin, setRouteOrigin] = useState<google.maps.LatLngLiteral | null>(null);
  const [routeDest, setRouteDest] = useState<google.maps.LatLngLiteral | null>(null);
  const [routeInfo, setRouteInfo] = useState<{ distance: string; duration: string } | null>(null);
  const [copied, setCopied] = useState(false);

  // Search Places using Places API (New)
  useEffect(() => {
    if (!placesLib || !searchQuery.trim()) return;

    setIsSearching(true);
    placesLib.Place.searchByText({
      textQuery: searchQuery,
      fields: ['displayName', 'location', 'formattedAddress', 'id'],
      locationBias: map?.getCenter() || { lat: 37.7749, lng: -122.4194 },
      maxResultCount: 8,
    }).then(({ places: fetchedPlaces }) => {
      if (fetchedPlaces && fetchedPlaces.length > 0) {
        const mapped = fetchedPlaces
          .filter(p => p.location)
          .map(p => {
            const loc = p.location as any;
            const latVal = typeof loc?.lat === 'function' ? loc.lat() : Number(loc?.lat || 0);
            const lngVal = typeof loc?.lng === 'function' ? loc.lng() : Number(loc?.lng || 0);
            return {
              id: p.id || Math.random().toString(),
              title: p.displayName || 'Location',
              location: {
                lat: latVal,
                lng: lngVal,
              },
              address: p.formattedAddress
            };
          });
        setPlaces(mapped);

        // Center on the first result
        if (map && mapped[0]) {
          map.panTo(mapped[0].location);
          map.setZoom(13);
          setSelectedLocation(mapped[0]);
          setSelectedPlaceId(mapped[0].id);
        }
      }
    }).catch(err => {
      console.error('Places search failed:', err);
    }).finally(() => {
      setIsSearching(false);
    });
  }, [placesLib, searchQuery, map]);

  const handleMapClick = (e: any) => {
    if (e.detail?.latLng) {
      const lat = e.detail.latLng.lat;
      const lng = e.detail.latLng.lng;
      const newLoc = {
        lat,
        lng,
        title: `Pinned Location (${lat.toFixed(4)}, ${lng.toFixed(4)})`,
        address: 'Custom coordinates'
      };
      setSelectedLocation(newLoc);
      setSelectedPlaceId('custom-pin');
    }
  };

  const copyPythonCode = () => {
    if (!selectedLocation) return;
    const pythonCode = `# Location Coordinates
location = {
    "name": "${selectedLocation.title}",
    "latitude": ${selectedLocation.lat},
    "longitude": ${selectedLocation.lng},
    "address": "${selectedLocation.address || ''}"
}
print(f"Loaded {location['name']}: ({location['latitude']}, {location['longitude']})")`;
    
    navigator.clipboard.writeText(pythonCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);

    if (onInsertCode) {
      onInsertCode(pythonCode);
    }
  };

  return (
    <div className="relative w-full h-full">
      <Map
        defaultCenter={{ lat: 37.7749, lng: -122.4194 }}
        defaultZoom={11}
        mapId="DEMO_MAP_ID"
        internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        onClick={handleMapClick}
        style={{ width: '100%', height: '100%' }}
        gestureHandling="greedy"
        disableDefaultUI={false}
      >
        {places.map(p => (
          <PlaceMarker
            key={p.id}
            place={p}
            isSelected={selectedPlaceId === p.id}
            onSelect={() => {
              setSelectedPlaceId(p.id);
              setSelectedLocation(p);
            }}
            onClose={() => setSelectedPlaceId(null)}
          />
        ))}

        {selectedLocation && selectedPlaceId === 'custom-pin' && (
          <AdvancedMarker position={{ lat: selectedLocation.lat, lng: selectedLocation.lng }}>
            <Pin background="#ec4899" glyphColor="#fff" />
          </AdvancedMarker>
        )}

        <RouteDisplay 
          origin={routeOrigin} 
          destination={routeDest} 
          onRouteCalculated={setRouteInfo} 
        />
      </Map>

      {/* Floating Info Overlay */}
      {selectedLocation && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute bottom-4 left-4 right-4 md:right-auto md:w-96 bg-[#161922]/95 backdrop-blur-md border border-slate-800 rounded-xl p-4 shadow-2xl text-slate-200 z-10"
        >
          <div className="flex items-start justify-between gap-2 mb-2">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-indigo-500/10 text-indigo-400 rounded-lg">
                <MapPin className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <h4 className="font-bold text-xs truncate">{selectedLocation.title}</h4>
                <p className="text-[10px] text-slate-500 truncate">{selectedLocation.address || 'Custom Point'}</p>
              </div>
            </div>
            <button 
              onClick={() => setSelectedLocation(null)}
              className="text-slate-500 hover:text-slate-300 p-1"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="bg-[#0c0e14] p-2 rounded-lg font-mono text-[10px] text-indigo-300 mb-3 flex items-center justify-between">
            <span>lat: {selectedLocation.lat.toFixed(5)}, lng: {selectedLocation.lng.toFixed(5)}</span>
            <span className="text-[9px] text-slate-500 font-sans">WGS84</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={copyPythonCode}
              className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-bold transition-all shadow-md shadow-indigo-500/20"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Code className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied to Python!' : 'Export to Code'}</span>
            </button>
            <button
              onClick={() => {
                if (!routeOrigin) {
                  setRouteOrigin({ lat: selectedLocation.lat, lng: selectedLocation.lng });
                } else {
                  setRouteDest({ lat: selectedLocation.lat, lng: selectedLocation.lng });
                }
              }}
              className="flex items-center gap-1 py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs font-medium transition-all"
              title="Set as Route Waypoint"
            >
              <RouteIcon className="w-3.5 h-3.5 text-indigo-400" />
              <span>{!routeOrigin ? 'Route Origin' : 'Route Dest'}</span>
            </button>
          </div>

          {routeInfo && (
            <div className="mt-2.5 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[10px]">
              <span className="text-slate-400">Routes API: <strong className="text-indigo-400">{routeInfo.distance}</strong></span>
              <span className="text-slate-400">Est. Time: <strong className="text-emerald-400">{routeInfo.duration}</strong></span>
            </div>
          )}
        </motion.div>
      )}

      {isSearching && (
        <div className="absolute top-4 left-4 bg-[#161922]/90 backdrop-blur-md px-3 py-1.5 rounded-full border border-slate-800 text-[10px] text-indigo-300 flex items-center gap-2 shadow-lg">
          <Loader2 className="w-3.5 h-3.5 animate-spin" />
          <span>Searching Google Maps Platform...</span>
        </div>
      )}
    </div>
  );
}

export const MapsExplorer: React.FC<MapsExplorerProps> = ({ onClose, onInsertCode }) => {
  const [searchInput, setSearchInput] = useState('');
  const [activeQuery, setActiveQuery] = useState('Googleplex Mountain View');
  const [selectedLocation, setSelectedLocation] = useState<{ lat: number; lng: number; title: string; address?: string } | null>(null);

  const presets = [
    { name: 'Googleplex HQ', query: 'Googleplex Mountain View' },
    { name: 'Tokyo Tower', query: 'Tokyo Tower Japan' },
    { name: 'Eiffel Tower', query: 'Eiffel Tower Paris' },
    { name: 'Sydney Opera House', query: 'Sydney Opera House Australia' },
  ];

  if (!hasValidKey) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.96 }}
        className="fixed inset-4 md:inset-16 lg:inset-24 bg-[#0c0e14] border border-slate-800 rounded-2xl shadow-2xl flex flex-col z-50 overflow-hidden"
      >
        <div className="h-14 border-b border-slate-800 flex items-center justify-between px-6 bg-[#161922]">
          <div className="flex items-center gap-3 text-indigo-400">
            <Compass className="w-5 h-5" />
            <span className="font-bold uppercase tracking-widest text-xs">Google Maps Platform Studio</span>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-800 rounded-full transition-colors text-slate-500 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 flex items-center justify-center p-8 overflow-y-auto">
          <div className="max-w-lg w-full bg-[#161922] p-8 rounded-2xl border border-slate-800 text-center shadow-xl">
            <div className="w-16 h-16 bg-indigo-500/10 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-indigo-500/20">
              <MapPin className="w-8 h-8 text-indigo-400" />
            </div>
            
            <h2 className="text-lg font-bold text-slate-100 mb-2">Google Maps API Key Required</h2>
            <p className="text-xs text-slate-400 mb-6 leading-relaxed">
              Connect your Google Maps Platform API key to explore live maps, search places, calculate driving routes, and import coordinates into your Python scripts.
            </p>

            <div className="bg-[#0f1117] p-5 rounded-xl border border-slate-800 text-left mb-6 space-y-3 text-xs text-slate-300">
              <p>
                <strong className="text-white">Step 1:</strong>{' '}
                <a 
                  href="https://console.cloud.google.com/google/maps-apis/start?utm_campaign=gmp-code-assist-ais" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-indigo-400 hover:underline inline-flex items-center gap-1"
                >
                  Get an API Key <ExternalLink className="w-3 h-3 inline" />
                </a>
              </p>
              <p><strong className="text-white">Step 2:</strong> Add your key as a secret in AI Studio:</p>
              <ul className="list-disc list-inside text-slate-400 pl-1 space-y-1.5 text-[11px]">
                <li>Open <strong>Settings</strong> (⚙️ gear icon, <strong>top-right corner</strong>)</li>
                <li>Select <strong>Secrets</strong></li>
                <li>Type <code className="bg-slate-800 px-1 py-0.5 rounded text-indigo-300">GOOGLE_MAPS_PLATFORM_KEY</code> as the secret name, press <strong>Enter</strong></li>
                <li>Paste your API key as the value, press <strong>Enter</strong></li>
              </ul>
              <p className="text-[10px] text-slate-500 italic pt-1">The app rebuilds automatically after you add the secret.</p>
            </div>

            <button 
              onClick={onClose}
              className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition-all"
            >
              Close
            </button>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.96 }}
      className="fixed inset-4 md:inset-12 lg:inset-20 bg-[#0c0e14] border border-slate-800 rounded-2xl shadow-2xl flex flex-col z-50 overflow-hidden"
    >
      {/* Header Bar */}
      <div className="h-16 border-b border-slate-800 flex items-center justify-between px-6 bg-[#161922] gap-4">
        <div className="flex items-center gap-3 text-indigo-400 shrink-0">
          <Compass className="w-5 h-5" />
          <span className="font-bold uppercase tracking-widest text-xs hidden sm:inline">Maps Explorer</span>
        </div>

        {/* Search Input Bar */}
        <div className="flex-1 max-w-md relative">
          <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-500" />
          <input
            type="text"
            placeholder="Search places or coordinates (e.g., Mountain View, CA)..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && searchInput.trim()) {
                setActiveQuery(searchInput);
              }
            }}
            className="w-full bg-[#0f1117] border border-slate-800 rounded-lg py-2 pl-9 pr-20 text-xs text-slate-200 focus:outline-none focus:border-indigo-500/50 transition-all placeholder:text-slate-600"
          />
          <button
            onClick={() => searchInput.trim() && setActiveQuery(searchInput)}
            className="absolute right-1.5 top-1.5 px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-[10px] font-bold transition-all shadow-md shadow-indigo-500/20"
          >
            Search
          </button>
        </div>

        {/* Preset quick links */}
        <div className="hidden lg:flex items-center gap-2">
          {presets.map(preset => (
            <button
              key={preset.name}
              onClick={() => {
                setSearchInput(preset.query);
                setActiveQuery(preset.query);
              }}
              className="px-2.5 py-1 bg-slate-800/80 hover:bg-slate-800 text-[10px] font-medium text-slate-400 hover:text-slate-200 rounded-full border border-slate-700/50 transition-all truncate"
            >
              {preset.name}
            </button>
          ))}
        </div>

        <button 
          onClick={onClose} 
          className="p-2 hover:bg-slate-800 rounded-full transition-colors text-slate-500 hover:text-white shrink-0"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Map Body */}
      <div className="flex-1 relative overflow-hidden">
        <APIProvider apiKey={API_KEY} version="weekly">
          <MapContent
            searchQuery={activeQuery}
            onInsertCode={onInsertCode}
            selectedLocation={selectedLocation}
            setSelectedLocation={setSelectedLocation}
          />
        </APIProvider>
      </div>
    </motion.div>
  );
};
