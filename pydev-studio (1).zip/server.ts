import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { exec } from "child_process";
import fs from "fs/promises";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Gemini Setup
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// API: Execute Python
app.post("/api/execute", async (req, res) => {
  const { code, tests } = req.body;
  
  // Combine code and tests
  const fullCode = `${code}\n\n${tests || ""}`;
  const fileName = `temp_${Date.now()}.py`;
  const tempFile = path.join(process.cwd(), fileName);
  
  try {
    await fs.writeFile(tempFile, fullCode);
    const startHr = process.hrtime.bigint();
    
    // Execute python script and benchmark
    exec(`python3 -c "import tracemalloc, time, runpy, sys; tracemalloc.start(); t0=time.perf_counter(); runpy.run_path('${tempFile}', run_name='__main__'); t1=time.perf_counter(); _, peak=tracemalloc.get_traced_memory(); sys.stderr.write(f'\\n__PYDEV_STATS__:{int((t1-t0)*1000)}:{max(int(peak/1024), 64)}\\n')"`, async (error, stdout, stderr) => {
      const endHr = process.hrtime.bigint();
      const wallMs = Math.max(1, Math.round(Number(endHr - startHr) / 1000000));
      
      // Clean up file
      try {
        await fs.unlink(tempFile);
      } catch (err) {
        console.error("Failed to delete temp file", err);
      }
      
      let executionTimeMs = wallMs;
      let memoryKb = Math.min(25600, Math.max(128, Math.round(fullCode.length / 10) + 256));
      let cleanStderr = stderr;
      
      const statsMatch = stderr.match(/__PYDEV_STATS__:(\d+):(\d+)/);
      if (statsMatch) {
        const measuredMs = parseInt(statsMatch[1], 10);
        executionTimeMs = measuredMs >= 0 ? measuredMs : wallMs;
        memoryKb = parseInt(statsMatch[2], 10) || memoryKb;
        cleanStderr = stderr.replace(/\n?__PYDEV_STATS__:\d+:\d+\r?\n?/, '').trimEnd();
      } else if (error) {
        // If runpy wrapper failed with exception, clean up any internal wrapper traceback noise
        cleanStderr = stderr.replace(/Traceback \(most recent call last\):\s+File "<string>".*runpy\.py", line \d+, in _run_code_node\s+/s, '');
      }
      
      res.json({
        success: !error,
        stdout,
        stderr: cleanStderr,
        error: error ? error.message : null,
        executionTimeMs,
        memoryKb
      });
    });
  } catch (err) {
    res.status(500).json({ error: "Failed to execute code" });
  }
});

// API: Package Management
app.get("/api/packages", (req, res) => {
  // Try multiple commands to find pip
  const commands = [
    "pip3 list --format=json",
    "pip list --format=json",
    "python3 -m pip list --format=json"
  ];
  
  const tryCommand = (index: number) => {
    if (index >= commands.length) {
      console.warn("All pip list commands failed.");
      return res.json([]); // Return empty list instead of 500
    }
    
    exec(commands[index], (error, stdout, stderr) => {
      if (error) {
        return tryCommand(index + 1);
      }
      try {
        res.json(JSON.parse(stdout));
      } catch (e) {
        tryCommand(index + 1);
      }
    });
  };
  
  tryCommand(0);
});

app.post("/api/packages/install", (req, res) => {
  const { name } = req.body;
  if (!name || !/^[a-zA-Z0-9_-]+$/.test(name)) {
    return res.status(400).json({ error: "Invalid package name" });
  }

  // Try pip3 then pip then python3 -m pip
  const cmd = `pip3 install ${name} || pip install ${name} || python3 -m pip install ${name}`;
  exec(cmd, (error, stdout, stderr) => {
    res.json({
      success: !error,
      stdout,
      stderr,
      error: error ? error.message : null
    });
  });
});

app.post("/api/packages/uninstall", (req, res) => {
  const { name } = req.body;
  if (!name || !/^[a-zA-Z0-9_-]+$/.test(name)) {
    return res.status(400).json({ error: "Invalid package name" });
  }

  const cmd = `pip3 uninstall -y ${name} || pip uninstall -y ${name} || python3 -m pip uninstall -y ${name}`;
  exec(cmd, (error, stdout, stderr) => {
    res.json({
      success: !error,
      stdout,
      stderr,
      error: error ? error.message : null
    });
  });
});

// API: AI Suggestion
app.post("/api/ai/suggest", async (req, res) => {
  const { code, context } = req.body;
  
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    console.error("GEMINI_API_KEY is not set or is placeholder");
    return res.status(400).json({ error: "Gemini API key is not configured in Secrets." });
  }

  try {
    const prompt = `You are a Python expert. Analyze this code and provide suggestions for improvement, debugging, or test cases.
    
    Code:
    ${code}
    
    Context:
    ${context}
    
    Return a JSON response with 'suggestions' (array of strings) and 'improvedCode' (string). 
    Ensure the response is valid JSON. Do not include markdown formatting in the JSON itself.`;
    
    console.log("Calling Gemini API with model gemini-3.6-flash...");
    const result = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
    });
    
    const text = result.text;
    console.log("Gemini API returned response.");
    
    if (!text) {
        throw new Error("Empty response from Gemini");
    }

    try {
        // Find JSON block in the response
        const jsonMatch = text.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
            res.json(JSON.parse(jsonMatch[0]));
        } else {
            res.json({ suggestions: [text], improvedCode: code });
        }
    } catch (e) {
        console.warn("Failed to parse Gemini response as JSON, returning raw text as suggestion.");
        res.json({ suggestions: [text], improvedCode: code });
    }
  } catch (err: any) {
    console.error("AI Error:", err);
    res.status(500).json({ error: `AI Suggestion failed: ${err.message || "Unknown error"}` });
  }
});

// Helper for GitHub API requests
const GITHUB_API_URL = "https://api.github.com";

// OAuth: Get GitHub Authorization URL
app.get("/api/auth/github/url", (req, res) => {
  const clientId = process.env.GITHUB_CLIENT_ID || process.env.CLIENT_ID;
  if (!clientId || clientId === "MY_GITHUB_CLIENT_ID") {
    return res.json({ 
      configured: false, 
      error: "GITHUB_CLIENT_ID is not configured in Secrets." 
    });
  }

  const origin = (req.query.origin as string) || process.env.APP_URL || `${req.protocol}://${req.get('host')}`;
  const redirectUri = `${origin.replace(/\/$/, '')}/auth/callback`;
  const state = Math.random().toString(36).substring(2, 15);

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    scope: "repo,read:user,user:email",
    state: state
  });

  const authUrl = `https://github.com/login/oauth/authorize?${params.toString()}`;
  res.json({ configured: true, url: authUrl, redirectUri });
});

// OAuth: GitHub Callback Handler
const githubCallbackHandler = async (req: express.Request, res: express.Response) => {
  const { code, error, error_description } = req.query;

  if (error || !code) {
    return res.send(`
      <!DOCTYPE html>
      <html>
        <head><title>GitHub Authentication Failed</title></head>
        <body style="font-family:system-ui,sans-serif; background:#0c0e14; color:#f87171; display:flex; align-items:center; justify-content:center; height:100vh; margin:0; text-align:center;">
          <div>
            <h3>Authentication Failed</h3>
            <p style="color:#94a3b8; font-size:13px;">${error_description || error || "Authorization was cancelled or failed."}</p>
            <button onclick="window.close()" style="background:#1e293b; color:#fff; border:none; padding:8px 16px; border-radius:6px; cursor:pointer;">Close Window</button>
          </div>
        </body>
      </html>
    `);
  }

  const clientId = process.env.GITHUB_CLIENT_ID || process.env.CLIENT_ID;
  const clientSecret = process.env.GITHUB_CLIENT_SECRET || process.env.CLIENT_SECRET;

  if (!clientId || !clientSecret) {
    return res.status(500).send("GitHub OAuth Client ID or Secret is not configured.");
  }

  try {
    // Exchange code for access token
    const tokenResponse = await fetch("https://github.com/login/oauth/access_token", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "PyDevStudio"
      },
      body: JSON.stringify({
        client_id: clientId,
        client_secret: clientSecret,
        code: code
      })
    });

    const tokenData = await tokenResponse.json() as any;

    if (tokenData.error || !tokenData.access_token) {
      throw new Error(tokenData.error_description || tokenData.error || "Failed to retrieve access token");
    }

    const accessToken = tokenData.access_token;

    // Fetch User Profile
    const userResponse = await fetch(`${GITHUB_API_URL}/user`, {
      headers: {
        "Authorization": `Bearer ${accessToken}`,
        "Accept": "application/vnd.github+json",
        "User-Agent": "PyDevStudio"
      }
    });

    const userData = await userResponse.json() as any;

    const safeUser = {
      login: userData.login,
      name: userData.name || userData.login,
      avatar_url: userData.avatar_url,
      html_url: userData.html_url,
      public_repos: userData.public_repos
    };

    res.send(`
      <!DOCTYPE html>
      <html>
        <head><title>GitHub Authentication</title></head>
        <body style="font-family:system-ui,sans-serif; background:#0c0e14; color:#f1f5f9; display:flex; align-items:center; justify-content:center; height:100vh; margin:0;">
          <script>
            if (window.opener) {
              window.opener.postMessage({
                type: 'OAUTH_AUTH_SUCCESS',
                provider: 'github',
                token: ${JSON.stringify(accessToken)},
                user: ${JSON.stringify(safeUser)}
              }, '*');
              window.close();
            } else {
              window.location.href = '/';
            }
          </script>
          <div style="text-align:center; padding:20px;">
            <h3 style="color:#818cf8; margin-bottom:8px;">GitHub Authentication Successful!</h3>
            <p style="color:#94a3b8; font-size:13px;">Closing popup and returning to PyDev Studio...</p>
          </div>
        </body>
      </html>
    `);
  } catch (err: any) {
    console.error("GitHub OAuth Callback Error:", err);
    res.status(500).send(`Authentication error: ${err.message}`);
  }
};

app.get("/auth/callback", githubCallbackHandler);
app.get("/auth/callback/", githubCallbackHandler);

// API: Get user profile & verify token
app.post("/api/github/user", async (req, res) => {
  const { token } = req.body;
  if (!token) {
    return res.status(400).json({ error: "Token is required" });
  }

  try {
    const userRes = await fetch(`${GITHUB_API_URL}/user`, {
      headers: {
        "Authorization": `Bearer ${token}`,
        "Accept": "application/vnd.github+json",
        "User-Agent": "PyDevStudio"
      }
    });

    if (!userRes.ok) {
      const err = await userRes.json();
      return res.status(userRes.status).json(err);
    }

    const userData = await userRes.json();
    res.json(userData);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// API: List user repositories
app.post("/api/github/repos", async (req, res) => {
  const { token } = req.body;
  if (!token) {
    return res.status(400).json({ error: "Token is required" });
  }

  try {
    const repoRes = await fetch(`${GITHUB_API_URL}/user/repos?sort=updated&per_page=100`, {
      headers: {
        "Authorization": `Bearer ${token}`,
        "Accept": "application/vnd.github+json",
        "User-Agent": "PyDevStudio"
      }
    });

    if (!repoRes.ok) {
      const err = await repoRes.json();
      return res.status(repoRes.status).json(err);
    }

    const repos = await repoRes.json();
    res.json(repos);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// API: Create new repository
app.post("/api/github/create-repo", async (req, res) => {
  const { token, name, description, isPrivate } = req.body;
  if (!token || !name) {
    return res.status(400).json({ error: "Token and repository name are required" });
  }

  try {
    const createRes = await fetch(`${GITHUB_API_URL}/user/repos`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json",
        "Accept": "application/vnd.github+json",
        "User-Agent": "PyDevStudio"
      },
      body: JSON.stringify({
        name,
        description: description || "Python function snippets synced from PyDev Studio",
        private: Boolean(isPrivate),
        auto_init: true
      })
    });

    if (!createRes.ok) {
      const err = await createRes.json();
      return res.status(createRes.status).json(err);
    }

    const newRepo = await createRes.json();
    res.json(newRepo);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// API: Push snippets to GitHub repository
app.post("/api/github/push", async (req, res) => {
  const { token, owner, repo, branch = "main", message, snippets } = req.body;
  if (!token || !owner || !repo || !Array.isArray(snippets)) {
    return res.status(400).json({ error: "Missing required push parameters" });
  }

  const commitMsg = message || `Update ${snippets.length} Python function snippets from PyDev Studio`;

  try {
    // 1. Prepare snippets.json content
    const snippetsJsonContent = Buffer.from(
      JSON.stringify(snippets, null, 2),
      "utf-8"
    ).toString("base64");

    // Check if snippets.json already exists to get SHA
    let existingSha: string | undefined;
    const checkFile = await fetch(
      `${GITHUB_API_URL}/repos/${owner}/${repo}/contents/snippets.json?ref=${branch}`,
      {
        headers: {
          "Authorization": `Bearer ${token}`,
          "Accept": "application/vnd.github+json",
          "User-Agent": "PyDevStudio"
        }
      }
    );

    if (checkFile.ok) {
      const fileData = await checkFile.json() as any;
      existingSha = fileData.sha;
    }

    // Put snippets.json
    const putRes = await fetch(
      `${GITHUB_API_URL}/repos/${owner}/${repo}/contents/snippets.json`,
      {
        method: "PUT",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
          "Accept": "application/vnd.github+json",
          "User-Agent": "PyDevStudio"
        },
        body: JSON.stringify({
          message: commitMsg,
          content: snippetsJsonContent,
          branch,
          ...(existingSha ? { sha: existingSha } : {})
        })
      }
    );

    if (!putRes.ok) {
      const err = await putRes.json();
      return res.status(putRes.status).json(err);
    }

    const commitResult = await putRes.json();

    // 2. Also write/update README.md for a great developer experience
    const readmeMarkdown = `# Python Snippets Vault
*Synced from PyDev Studio on ${new Date().toISOString()}*

This repository contains ${snippets.length} curated Python function snippet(s).

## Snippets List
${snippets.map((s: any, idx: number) => `
### ${idx + 1}. ${s.name}
> ${s.description || 'No description provided.'}

\`\`\`python
${s.code}
\`\`\`
${s.tests ? `**Tests:**\n\`\`\`python\n${s.tests}\n\`\`\`` : ''}
`).join('\n---\n')}
`;

    let readmeSha: string | undefined;
    const checkReadme = await fetch(
      `${GITHUB_API_URL}/repos/${owner}/${repo}/contents/README.md?ref=${branch}`,
      {
        headers: {
          "Authorization": `Bearer ${token}`,
          "Accept": "application/vnd.github+json",
          "User-Agent": "PyDevStudio"
        }
      }
    );

    if (checkReadme.ok) {
      const rData = await checkReadme.json() as any;
      readmeSha = rData.sha;
    }

    await fetch(
      `${GITHUB_API_URL}/repos/${owner}/${repo}/contents/README.md`,
      {
        method: "PUT",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
          "Accept": "application/vnd.github+json",
          "User-Agent": "PyDevStudio"
        },
        body: JSON.stringify({
          message: `docs: update README with ${snippets.length} Python snippets`,
          content: Buffer.from(readmeMarkdown, "utf-8").toString("base64"),
          branch,
          ...(readmeSha ? { sha: readmeSha } : {})
        })
      }
    );

    res.json({
      success: true,
      commit: commitResult.commit,
      repoUrl: `https://github.com/${owner}/${repo}`,
      snippetsCount: snippets.length
    });
  } catch (err: any) {
    console.error("Push to GitHub error:", err);
    res.status(500).json({ error: err.message });
  }
});

// API: Pull snippets from GitHub repository
app.post("/api/github/pull", async (req, res) => {
  const { token, owner, repo, branch = "main" } = req.body;
  if (!token || !owner || !repo) {
    return res.status(400).json({ error: "Missing required pull parameters" });
  }

  try {
    // 1. Try to fetch snippets.json first
    const getRes = await fetch(
      `${GITHUB_API_URL}/repos/${owner}/${repo}/contents/snippets.json?ref=${branch}`,
      {
        headers: {
          "Authorization": `Bearer ${token}`,
          "Accept": "application/vnd.github+json",
          "User-Agent": "PyDevStudio"
        }
      }
    );

    if (getRes.ok) {
      const data = await getRes.json() as any;
      const content = Buffer.from(data.content, "base64").toString("utf-8");
      const snippets = JSON.parse(content);
      return res.json({ success: true, snippets, source: "snippets.json" });
    }

    // 2. If snippets.json not found, try reading repo root files for .py files
    const listRes = await fetch(
      `${GITHUB_API_URL}/repos/${owner}/${repo}/contents?ref=${branch}`,
      {
        headers: {
          "Authorization": `Bearer ${token}`,
          "Accept": "application/vnd.github+json",
          "User-Agent": "PyDevStudio"
        }
      }
    );

    if (!listRes.ok) {
      return res.status(404).json({ error: "No snippets.json or repository contents found." });
    }

    const items = await listRes.json() as any[];
    const pyFiles = items.filter(item => item.type === "file" && item.name.endsWith(".py"));

    if (pyFiles.length === 0) {
      return res.status(404).json({ 
        error: "Repository found, but no 'snippets.json' or '.py' files were detected. Push your current snippets first!" 
      });
    }

    const parsedSnippets = await Promise.all(
      pyFiles.map(async (file, idx) => {
        const fileContentRes = await fetch(file.url, {
          headers: {
            "Authorization": `Bearer ${token}`,
            "Accept": "application/vnd.github+json",
            "User-Agent": "PyDevStudio"
          }
        });
        const fileData = await fileContentRes.json() as any;
        const code = Buffer.from(fileData.content, "base64").toString("utf-8");
        return {
          id: `gh-${Date.now()}-${idx}`,
          name: file.name.replace(/\.py$/, "").replace(/[_-]/g, " ").replace(/\b\w/g, l => l.toUpperCase()),
          description: `Imported from ${repo}/${file.name}`,
          code: code,
          tests: `# Tests for ${file.name}\nprint("Imported from GitHub")`
        };
      })
    );

    res.json({ success: true, snippets: parsedSnippets, source: "python_files" });
  } catch (err: any) {
    console.error("Pull from GitHub error:", err);
    res.status(500).json({ error: err.message });
  }
});

// Vite Middleware
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
