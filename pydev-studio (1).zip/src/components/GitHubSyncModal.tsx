import React, { useState, useEffect } from 'react';
import { 
  Github, 
  Upload, 
  Download, 
  Check, 
  AlertCircle, 
  Loader2, 
  X, 
  ExternalLink, 
  FolderGit2, 
  Plus, 
  RefreshCw, 
  Key, 
  ShieldCheck, 
  GitBranch, 
  FileCode, 
  Copy,
  Info,
  Lock,
  Globe
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { FunctionSnippet } from '../types';

interface GitHubSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  snippets: FunctionSnippet[];
  onImportSnippets: (imported: FunctionSnippet[], merge: boolean) => void;
}

interface GitHubUser {
  login: string;
  name: string;
  avatar_url: string;
  html_url: string;
  public_repos?: number;
}

interface GitHubRepo {
  id: number;
  name: string;
  full_name: string;
  private: boolean;
  default_branch: string;
  description?: string;
  html_url: string;
}

const STORAGE_KEY_TOKEN = 'pydev_github_token';
const STORAGE_KEY_USER = 'pydev_github_user';
const STORAGE_KEY_REPO = 'pydev_github_selected_repo';

export const GitHubSyncModal: React.FC<GitHubSyncModalProps> = ({
  isOpen,
  onClose,
  snippets,
  onImportSnippets,
}) => {
  const [token, setToken] = useState<string>(() => localStorage.getItem(STORAGE_KEY_TOKEN) || '');
  const [user, setUser] = useState<GitHubUser | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_USER);
    return saved ? JSON.parse(saved) : null;
  });

  const [activeTab, setActiveTab] = useState<'sync' | 'oauth_setup' | 'pat'>('sync');
  const [repos, setRepos] = useState<GitHubRepo[]>([]);
  const [selectedRepo, setSelectedRepo] = useState<string>(() => localStorage.getItem(STORAGE_KEY_REPO) || '');
  const [selectedBranch, setSelectedBranch] = useState<string>('main');
  const [isLoadingRepos, setIsLoadingRepos] = useState(false);
  const [isPushing, setIsPushing] = useState(false);
  const [isPulling, setIsPulling] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string; link?: string } | null>(null);

  // New Repo Creation State
  const [showCreateRepo, setShowCreateRepo] = useState(false);
  const [newRepoName, setNewRepoName] = useState('python-snippets-vault');
  const [newRepoPrivate, setNewRepoPrivate] = useState(false);
  const [isCreatingRepo, setIsCreatingRepo] = useState(false);

  // Commit message
  const [commitMessage, setCommitMessage] = useState('');
  // Manual PAT input
  const [patInput, setPatInput] = useState('');
  const [copiedCallback, setCopiedCallback] = useState(false);

  const devCallbackUrl = "https://ais-dev-ceiool77uqro2qclumtyvx-721391878984.asia-east1.run.app/auth/callback";
  const sharedCallbackUrl = "https://ais-pre-ceiool77uqro2qclumtyvx-721391878984.asia-east1.run.app/auth/callback";

  // Listen for OAuth postMessage
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      const origin = event.origin;
      if (!origin.endsWith('.run.app') && !origin.includes('localhost')) {
        return;
      }

      if (event.data?.type === 'OAUTH_AUTH_SUCCESS' && event.data?.provider === 'github') {
        const receivedToken = event.data.token;
        const receivedUser = event.data.user;

        if (receivedToken) {
          setToken(receivedToken);
          setUser(receivedUser);
          localStorage.setItem(STORAGE_KEY_TOKEN, receivedToken);
          if (receivedUser) {
            localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(receivedUser));
          }
          setIsConnecting(false);
          setStatusMessage({
            type: 'success',
            text: `Successfully connected as @${receivedUser?.login || 'GitHub User'}!`
          });
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  // Fetch repositories when token is present
  useEffect(() => {
    if (token) {
      fetchRepositories();
    }
  }, [token]);

  const fetchRepositories = async () => {
    if (!token) return;
    setIsLoadingRepos(true);
    try {
      const res = await fetch('/api/github/repos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || 'Failed to fetch repositories');
      }

      const repoList: GitHubRepo[] = await res.json();
      setRepos(repoList);

      if (repoList.length > 0) {
        const exists = repoList.some(r => r.full_name === selectedRepo);
        if (!exists) {
          setSelectedRepo(repoList[0].full_name);
          setSelectedBranch(repoList[0].default_branch || 'main');
          localStorage.setItem(STORAGE_KEY_REPO, repoList[0].full_name);
        }
      }
    } catch (err: any) {
      console.error('Fetch repos error:', err);
      setStatusMessage({ type: 'error', text: err.message });
    } finally {
      setIsLoadingRepos(false);
    }
  };

  const handleOAuthConnect = async () => {
    setIsConnecting(true);
    setStatusMessage(null);
    try {
      const origin = window.location.origin;
      const res = await fetch(`/api/auth/github/url?origin=${encodeURIComponent(origin)}`);
      const data = await res.json();

      if (!data.configured) {
        setIsConnecting(false);
        setActiveTab('oauth_setup');
        setStatusMessage({
          type: 'info',
          text: 'GitHub OAuth Client ID is not configured yet in Secrets. Follow the instructions below or use a Personal Access Token.'
        });
        return;
      }

      const popup = window.open(
        data.url,
        'github_oauth_popup',
        'width=600,height=720,menubar=no,toolbar=no'
      );

      if (!popup) {
        setIsConnecting(false);
        setStatusMessage({
          type: 'error',
          text: 'Popup was blocked by your browser. Please allow popups for this site to continue.'
        });
      }
    } catch (err: any) {
      setIsConnecting(false);
      setStatusMessage({ type: 'error', text: err.message });
    }
  };

  const handleManualPatSave = async () => {
    if (!patInput.trim()) return;
    setIsConnecting(true);
    setStatusMessage(null);

    try {
      const res = await fetch('/api/github/user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: patInput.trim() })
      });

      if (!res.ok) {
        throw new Error('Invalid token or insufficient permissions');
      }

      const userData = await res.json();
      const safeUser: GitHubUser = {
        login: userData.login,
        name: userData.name || userData.login,
        avatar_url: userData.avatar_url,
        html_url: userData.html_url,
        public_repos: userData.public_repos
      };

      setToken(patInput.trim());
      setUser(safeUser);
      localStorage.setItem(STORAGE_KEY_TOKEN, patInput.trim());
      localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(safeUser));
      setActiveTab('sync');
      setStatusMessage({
        type: 'success',
        text: `Connected with Personal Access Token as @${safeUser.login}!`
      });
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: err.message });
    } finally {
      setIsConnecting(false);
    }
  };

  const handleCreateRepo = async () => {
    if (!newRepoName.trim() || !token) return;
    setIsCreatingRepo(true);
    setStatusMessage(null);

    try {
      const res = await fetch('/api/github/create-repo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          name: newRepoName.trim(),
          isPrivate: newRepoPrivate,
          description: 'Python function snippets repository managed by PyDev Studio'
        })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || 'Failed to create repository');
      }

      const created = await res.json();
      await fetchRepositories();
      setSelectedRepo(created.full_name);
      setSelectedBranch(created.default_branch || 'main');
      localStorage.setItem(STORAGE_KEY_REPO, created.full_name);
      setShowCreateRepo(false);
      setStatusMessage({
        type: 'success',
        text: `Repository ${created.full_name} created successfully!`,
        link: created.html_url
      });
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: err.message });
    } finally {
      setIsCreatingRepo(false);
    }
  };

  const handlePush = async () => {
    if (!selectedRepo || !token) return;
    const [owner, repo] = selectedRepo.split('/');
    if (!owner || !repo) return;

    setIsPushing(true);
    setStatusMessage(null);

    try {
      const res = await fetch('/api/github/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          owner,
          repo,
          branch: selectedBranch || 'main',
          message: commitMessage.trim() || undefined,
          snippets
        })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || 'Failed to push snippets to GitHub');
      }

      const data = await res.json();
      setStatusMessage({
        type: 'success',
        text: `Successfully pushed ${snippets.length} function snippets to ${selectedRepo}!`,
        link: data.repoUrl
      });
      setCommitMessage('');
    } catch (err: any) {
      console.error('Push error:', err);
      setStatusMessage({ type: 'error', text: err.message });
    } finally {
      setIsPushing(false);
    }
  };

  const handlePull = async (merge: boolean) => {
    if (!selectedRepo || !token) return;
    const [owner, repo] = selectedRepo.split('/');
    if (!owner || !repo) return;

    setIsPulling(true);
    setStatusMessage(null);

    try {
      const res = await fetch('/api/github/pull', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          owner,
          repo,
          branch: selectedBranch || 'main'
        })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || 'Failed to pull snippets from GitHub');
      }

      const data = await res.json();
      if (!Array.isArray(data.snippets) || data.snippets.length === 0) {
        throw new Error('No snippets found in this repository');
      }

      onImportSnippets(data.snippets, merge);
      setStatusMessage({
        type: 'success',
        text: `Successfully imported ${data.snippets.length} snippet(s) from ${selectedRepo}!`
      });
    } catch (err: any) {
      console.error('Pull error:', err);
      setStatusMessage({ type: 'error', text: err.message });
    } finally {
      setIsPulling(false);
    }
  };

  const handleDisconnect = () => {
    setToken('');
    setUser(null);
    setRepos([]);
    setSelectedRepo('');
    localStorage.removeItem(STORAGE_KEY_TOKEN);
    localStorage.removeItem(STORAGE_KEY_USER);
    localStorage.removeItem(STORAGE_KEY_REPO);
    setStatusMessage({ type: 'info', text: 'Disconnected from GitHub.' });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 10 }}
        className="w-full max-w-2xl bg-[#0c0e14] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="h-16 border-b border-slate-800 flex items-center justify-between px-6 bg-[#161922]">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-slate-800 text-white rounded-xl border border-slate-700">
              <Github className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                <span>Sync with GitHub</span>
                {user && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 font-mono font-normal">
                    @{user.login}
                  </span>
                )}
              </h2>
              <p className="text-[11px] text-slate-400">Push and pull your Python function snippets to GitHub</p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="p-2 hover:bg-slate-800 rounded-full transition-colors text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-slate-800 bg-[#0f1117] px-6 text-xs">
          <button
            onClick={() => setActiveTab('sync')}
            className={`py-3 px-4 font-bold border-b-2 transition-all ${
              activeTab === 'sync'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Repository Sync
          </button>
          <button
            onClick={() => setActiveTab('oauth_setup')}
            className={`py-3 px-4 font-bold border-b-2 transition-all ${
              activeTab === 'oauth_setup'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            OAuth Setup Guide
          </button>
          <button
            onClick={() => setActiveTab('pat')}
            className={`py-3 px-4 font-bold border-b-2 transition-all ${
              activeTab === 'pat'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Personal Access Token (PAT)
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Status Message Banner */}
          {statusMessage && (
            <div className={`p-3.5 rounded-xl border flex items-start gap-3 text-xs leading-relaxed ${
              statusMessage.type === 'success' ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-300' :
              statusMessage.type === 'error' ? 'bg-rose-950/40 border-rose-800/60 text-rose-300' :
              'bg-indigo-950/40 border-indigo-800/60 text-indigo-300'
            }`}>
              {statusMessage.type === 'success' ? <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" /> :
               statusMessage.type === 'error' ? <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" /> :
               <Info className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />}
              <div className="flex-1">
                <span>{statusMessage.text}</span>
                {statusMessage.link && (
                  <div className="mt-1">
                    <a 
                      href={statusMessage.link} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="underline font-bold inline-flex items-center gap-1 hover:opacity-80"
                    >
                      View on GitHub <ExternalLink className="w-3 h-3 inline" />
                    </a>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'sync' && (
            <>
              {!token ? (
                /* Disconnected State */
                <div className="bg-[#161922] p-8 rounded-2xl border border-slate-800 text-center space-y-5">
                  <div className="w-16 h-16 bg-slate-800 rounded-2xl flex items-center justify-center mx-auto border border-slate-700 text-white">
                    <Github className="w-8 h-8" />
                  </div>
                  <div className="max-w-md mx-auto">
                    <h3 className="text-base font-bold text-slate-100 mb-1">Connect your GitHub Account</h3>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Authenticate with GitHub using OAuth to easily push your custom Python snippets or pull repositories into PyDev Studio.
                    </p>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                    <button
                      onClick={handleOAuthConnect}
                      disabled={isConnecting}
                      className="w-full sm:w-auto px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      {isConnecting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Github className="w-4 h-4" />}
                      <span>Connect with GitHub OAuth</span>
                    </button>
                    <button
                      onClick={() => setActiveTab('pat')}
                      className="w-full sm:w-auto px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-medium transition-all flex items-center justify-center gap-2"
                    >
                      <Key className="w-3.5 h-3.5" />
                      <span>Use Token (PAT)</span>
                    </button>
                  </div>
                </div>
              ) : (
                /* Connected State */
                <div className="space-y-6">
                  {/* Account Card */}
                  <div className="bg-[#161922] p-4 rounded-xl border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {user?.avatar_url ? (
                        <img 
                          src={user.avatar_url} 
                          alt={user.login} 
                          className="w-10 h-10 rounded-full border border-slate-700" 
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center border border-slate-700">
                          <Github className="w-5 h-5 text-slate-300" />
                        </div>
                      )}
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-xs text-white">{user?.name || user?.login}</h4>
                          <span className="text-[10px] text-slate-400 font-mono">@{user?.login}</span>
                        </div>
                        <p className="text-[10px] text-emerald-400 flex items-center gap-1 mt-0.5">
                          <ShieldCheck className="w-3 h-3" /> OAuth Connected
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={handleDisconnect}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-rose-950/50 hover:text-rose-300 text-slate-400 rounded-lg text-xs font-medium transition-all"
                    >
                      Disconnect
                    </button>
                  </div>

                  {/* Repository Selector */}
                  <div className="bg-[#161922] p-5 rounded-xl border border-slate-800 space-y-4">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-200 flex items-center gap-2">
                        <FolderGit2 className="w-4 h-4 text-indigo-400" />
                        <span>Target Repository</span>
                      </label>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={fetchRepositories}
                          disabled={isLoadingRepos}
                          className="p-1 text-slate-400 hover:text-white transition-colors"
                          title="Refresh Repositories"
                        >
                          <RefreshCw className={`w-3.5 h-3.5 ${isLoadingRepos ? 'animate-spin' : ''}`} />
                        </button>
                        <button
                          onClick={() => setShowCreateRepo(!showCreateRepo)}
                          className="text-[11px] text-indigo-400 hover:text-indigo-300 font-bold flex items-center gap-1"
                        >
                          <Plus className="w-3 h-3" />
                          <span>New Repo</span>
                        </button>
                      </div>
                    </div>

                    {showCreateRepo ? (
                      <div className="bg-[#0f1117] p-4 rounded-lg border border-indigo-500/30 space-y-3">
                        <div className="text-xs font-bold text-slate-200">Create New GitHub Repository</div>
                        <input
                          type="text"
                          placeholder="Repository name (e.g. my-python-snippets)"
                          value={newRepoName}
                          onChange={(e) => setNewRepoName(e.target.value)}
                          className="w-full bg-[#161922] border border-slate-800 rounded px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                        />
                        <div className="flex items-center justify-between">
                          <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={newRepoPrivate}
                              onChange={(e) => setNewRepoPrivate(e.target.checked)}
                              className="rounded bg-slate-800 border-slate-700"
                            />
                            <span>Make repository private</span>
                          </label>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => setShowCreateRepo(false)}
                              className="px-3 py-1 bg-slate-800 text-slate-400 rounded text-xs"
                            >
                              Cancel
                            </button>
                            <button
                              onClick={handleCreateRepo}
                              disabled={isCreatingRepo || !newRepoName.trim()}
                              className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-bold flex items-center gap-1.5 disabled:opacity-50"
                            >
                              {isCreatingRepo && <Loader2 className="w-3 h-3 animate-spin" />}
                              <span>Create Repo</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div className="sm:col-span-2">
                          <select
                            value={selectedRepo}
                            onChange={(e) => {
                              setSelectedRepo(e.target.value);
                              localStorage.setItem(STORAGE_KEY_REPO, e.target.value);
                              const r = repos.find(item => item.full_name === e.target.value);
                              if (r?.default_branch) {
                                setSelectedBranch(r.default_branch);
                              }
                            }}
                            className="w-full bg-[#0f1117] border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                          >
                            {repos.length === 0 ? (
                              <option value="">No repositories found</option>
                            ) : (
                              repos.map(r => (
                                <option key={r.id} value={r.full_name}>
                                  {r.full_name} {r.private ? '🔒 (Private)' : '🌐 (Public)'}
                                </option>
                              ))
                            )}
                          </select>
                        </div>
                        <div>
                          <div className="relative flex items-center">
                            <GitBranch className="absolute left-2.5 w-3.5 h-3.5 text-slate-500" />
                            <input
                              type="text"
                              placeholder="branch (e.g. main)"
                              value={selectedBranch}
                              onChange={(e) => setSelectedBranch(e.target.value)}
                              className="w-full bg-[#0f1117] border border-slate-800 rounded-lg pl-8 pr-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Actions Grid: Push & Pull */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Push Card */}
                    <div className="bg-[#161922] p-5 rounded-xl border border-slate-800 flex flex-col justify-between space-y-4">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <div className="p-1.5 bg-indigo-500/10 text-indigo-400 rounded-lg">
                            <Upload className="w-4 h-4" />
                          </div>
                          <h4 className="font-bold text-xs text-slate-100">Push to GitHub</h4>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
                          Upload your <strong className="text-white">{snippets.length} saved function snippets</strong> into <code className="text-indigo-300 font-mono text-[10px]">{selectedRepo || 'repo'}</code> as structured JSON & Python scripts.
                        </p>
                        <input
                          type="text"
                          placeholder="Optional commit message..."
                          value={commitMessage}
                          onChange={(e) => setCommitMessage(e.target.value)}
                          className="w-full bg-[#0f1117] border border-slate-800 rounded px-2.5 py-1.5 text-[11px] text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500"
                        />
                      </div>

                      <button
                        onClick={handlePush}
                        disabled={isPushing || !selectedRepo || snippets.length === 0}
                        className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold transition-all shadow-md shadow-indigo-600/20 flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
                      >
                        {isPushing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
                        <span>Push {snippets.length} Snippets</span>
                      </button>
                    </div>

                    {/* Pull Card */}
                    <div className="bg-[#161922] p-5 rounded-xl border border-slate-800 flex flex-col justify-between space-y-4">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <div className="p-1.5 bg-emerald-500/10 text-emerald-400 rounded-lg">
                            <Download className="w-4 h-4" />
                          </div>
                          <h4 className="font-bold text-xs text-slate-100">Pull from GitHub</h4>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
                          Download snippets and Python files from the selected repository directly into PyDev Studio.
                        </p>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() => handlePull(true)}
                          disabled={isPulling || !selectedRepo}
                          className="py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-[11px] font-bold transition-all flex items-center justify-center gap-1.5 disabled:opacity-50 cursor-pointer"
                          title="Merge imported snippets with your current list"
                        >
                          {isPulling ? <Loader2 className="w-3 h-3 animate-spin" /> : <Download className="w-3 h-3 text-emerald-400" />}
                          <span>Merge Pull</span>
                        </button>
                        <button
                          onClick={() => handlePull(false)}
                          disabled={isPulling || !selectedRepo}
                          className="py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-[11px] font-bold transition-all flex items-center justify-center gap-1.5 disabled:opacity-50 cursor-pointer"
                          title="Replace current snippets with repository contents"
                        >
                          {isPulling ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3 text-indigo-400" />}
                          <span>Replace All</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}

          {activeTab === 'oauth_setup' && (
            <div className="space-y-4 text-xs text-slate-300 leading-relaxed">
              <div className="bg-[#161922] p-5 rounded-xl border border-slate-800 space-y-4">
                <h3 className="font-bold text-sm text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-indigo-400" />
                  <span>GitHub OAuth App Configuration</span>
                </h3>
                <p className="text-slate-400 text-xs">
                  To enable one-click OAuth login in this application, register an OAuth App in GitHub Developer Settings:
                </p>

                <div className="space-y-3 pt-1">
                  <div>
                    <strong className="text-white block mb-1">1. Open GitHub Developer Dashboard:</strong>
                    <a 
                      href="https://github.com/settings/developers" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-indigo-400 hover:underline inline-flex items-center gap-1"
                    >
                      https://github.com/settings/developers <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>

                  <div>
                    <strong className="text-white block mb-1">2. Set the Authorization Callback URL in GitHub:</strong>
                    <div className="space-y-1.5">
                      <div className="bg-[#0f1117] p-2.5 rounded border border-slate-800 flex items-center justify-between font-mono text-[11px] text-indigo-300">
                        <span className="truncate">{devCallbackUrl}</span>
                        <button
                          onClick={() => {
                            navigator.clipboard.writeText(devCallbackUrl);
                            setCopiedCallback(true);
                            setTimeout(() => setCopiedCallback(false), 2000);
                          }}
                          className="text-slate-400 hover:text-white pl-2"
                        >
                          {copiedCallback ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                      <p className="text-[10px] text-slate-500">Shared/Production Callback: <code className="text-slate-400">{sharedCallbackUrl}</code></p>
                    </div>
                  </div>

                  <div>
                    <strong className="text-white block mb-1">3. Set Environment Secrets in AI Studio:</strong>
                    <ul className="list-disc list-inside text-slate-400 pl-1 space-y-1 text-[11px]">
                      <li>Open <strong>Settings</strong> (⚙️ gear icon in top right) → <strong>Secrets</strong></li>
                      <li>Add <code className="text-indigo-300 bg-slate-800 px-1 py-0.5 rounded">GITHUB_CLIENT_ID</code></li>
                      <li>Add <code className="text-indigo-300 bg-slate-800 px-1 py-0.5 rounded">GITHUB_CLIENT_SECRET</code></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'pat' && (
            <div className="space-y-4 text-xs text-slate-300">
              <div className="bg-[#161922] p-5 rounded-xl border border-slate-800 space-y-4">
                <div className="flex items-center gap-2 text-indigo-400">
                  <Key className="w-4 h-4" />
                  <h3 className="font-bold text-sm text-white">Direct Personal Access Token (PAT)</h3>
                </div>
                <p className="text-slate-400 text-xs leading-relaxed">
                  Alternatively, generate a classic or fine-grained token with <code className="text-indigo-300">repo</code> permissions on{' '}
                  <a 
                    href="https://github.com/settings/tokens" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-indigo-400 underline inline-flex items-center gap-0.5"
                  >
                    GitHub Settings <ExternalLink className="w-2.5 h-2.5" />
                  </a>.
                </p>

                <div className="space-y-2">
                  <label className="text-[11px] font-bold text-slate-400">Paste GitHub Token (ghp_...)</label>
                  <input
                    type="password"
                    placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                    value={patInput}
                    onChange={(e) => setPatInput(e.target.value)}
                    className="w-full bg-[#0f1117] border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 font-mono focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <button
                  onClick={handleManualPatSave}
                  disabled={isConnecting || !patInput.trim()}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold transition-all shadow-md shadow-indigo-600/20 flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
                >
                  {isConnecting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ShieldCheck className="w-3.5 h-3.5" />}
                  <span>Verify and Save Token</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="h-14 border-t border-slate-800 flex items-center justify-between px-6 bg-[#161922]">
          <span className="text-[10px] text-slate-500 font-mono">
            {snippets.length} snippet(s) loaded
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold transition-all"
          >
            Close
          </button>
        </div>
      </motion.div>
    </div>
  );
};
