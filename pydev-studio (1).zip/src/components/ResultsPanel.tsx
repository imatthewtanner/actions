import React, { useState, useMemo } from 'react';
import { 
  Terminal, 
  CheckCircle2, 
  AlertCircle, 
  Trash2, 
  Copy, 
  Check, 
  Search, 
  Filter, 
  Code2, 
  Info, 
  AlertTriangle, 
  Bug, 
  Flame, 
  CheckCheck,
  WrapText,
  Layers,
  Sparkles,
  Zap,
  Cpu,
  Clock
} from 'lucide-react';
import { ExecutionResult } from '../types';

interface ResultsPanelProps {
  result: ExecutionResult | null;
  onClear: () => void;
  onInsertLoggingDemo?: () => void;
}

type LogLevel = 'ALL' | 'DEBUG' | 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL' | 'TRACEBACK' | 'SUCCESS';

interface ParsedLogLine {
  id: number;
  level: LogLevel;
  raw: string;
  badgeText?: string;
  message: string;
  source?: string;
  timestamp?: string;
}

// Helper to categorize log lines
function parseLogLine(raw: string, index: number, isStderr: boolean): ParsedLogLine {
  const trimmed = raw.trim();

  // Python standard logging format: LEVEL:logger_name:message or LEVEL:message
  const stdLoggingRegex = /^(DEBUG|INFO|WARNING|WARN|ERROR|CRITICAL|FATAL):([a-zA-Z0-9_.]+)?:(.*)$/i;
  const stdMatch = trimmed.match(stdLoggingRegex);
  if (stdMatch) {
    const levelStr = stdMatch[1].toUpperCase();
    let level: LogLevel = 'INFO';
    if (levelStr === 'DEBUG') level = 'DEBUG';
    else if (levelStr === 'INFO') level = 'INFO';
    else if (levelStr === 'WARNING' || levelStr === 'WARN') level = 'WARNING';
    else if (levelStr === 'ERROR') level = 'ERROR';
    else if (levelStr === 'CRITICAL' || levelStr === 'FATAL') level = 'CRITICAL';

    const source = stdMatch[2] ? stdMatch[2].trim() : undefined;
    const message = stdMatch[3] ? stdMatch[3].trim() : trimmed;

    return {
      id: index,
      level,
      raw,
      badgeText: level === 'WARNING' ? 'WARN' : level,
      source,
      message
    };
  }

  // Bracketed format: [DEBUG] message or [2026-08-17 12:00:00] [INFO] message
  const bracketRegex = /^(?:\[(.*?)\]\s*)?\[(DEBUG|INFO|WARNING|WARN|ERROR|CRITICAL|FATAL)\]\s*(.*)$/i;
  const bracketMatch = trimmed.match(bracketRegex);
  if (bracketMatch) {
    const timestamp = bracketMatch[1];
    const levelStr = bracketMatch[2].toUpperCase();
    let level: LogLevel = 'INFO';
    if (levelStr === 'DEBUG') level = 'DEBUG';
    else if (levelStr === 'INFO') level = 'INFO';
    else if (levelStr === 'WARNING' || levelStr === 'WARN') level = 'WARNING';
    else if (levelStr === 'ERROR') level = 'ERROR';
    else if (levelStr === 'CRITICAL' || levelStr === 'FATAL') level = 'CRITICAL';

    return {
      id: index,
      level,
      raw,
      badgeText: level === 'WARNING' ? 'WARN' : level,
      timestamp,
      message: bracketMatch[3] || trimmed
    };
  }

  // Date formatted: 2026-08-17 12:00:00,000 - root - DEBUG - message
  const dateFormattedRegex = /^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}(?:,\d+)?\s*[-|:]\s*([a-zA-Z0-9_.]+)?\s*[-|:]\s*(DEBUG|INFO|WARNING|WARN|ERROR|CRITICAL|FATAL)\s*[-|:]\s*(.*)$/i;
  const dateMatch = trimmed.match(dateFormattedRegex);
  if (dateMatch) {
    const source = dateMatch[1];
    const levelStr = dateMatch[2].toUpperCase();
    let level: LogLevel = 'INFO';
    if (levelStr === 'DEBUG') level = 'DEBUG';
    else if (levelStr === 'INFO') level = 'INFO';
    else if (levelStr === 'WARNING' || levelStr === 'WARN') level = 'WARNING';
    else if (levelStr === 'ERROR') level = 'ERROR';
    else if (levelStr === 'CRITICAL' || levelStr === 'FATAL') level = 'CRITICAL';

    return {
      id: index,
      level,
      raw,
      badgeText: level === 'WARNING' ? 'WARN' : level,
      source,
      message: dateMatch[3] || trimmed
    };
  }

  // Python Tracebacks & Exceptions
  if (
    trimmed.startsWith('Traceback (most recent call last):') ||
    trimmed.startsWith('File "') ||
    /(?:Error|Exception|AssertionError|NameError|TypeError|ValueError|KeyError|IndexError|SyntaxError|ZeroDivisionError):/.test(trimmed)
  ) {
    return {
      id: index,
      level: 'TRACEBACK',
      raw,
      badgeText: 'TRACE',
      message: trimmed
    };
  }

  // Test results & Success markers
  if (/^(?:all tests passed|tests? passed|passed|ok|success)/i.test(trimmed)) {
    return {
      id: index,
      level: 'SUCCESS',
      badgeText: 'PASS',
      raw,
      message: trimmed
    };
  }

  // Fallback for Stderr
  if (isStderr) {
    return {
      id: index,
      level: 'ERROR',
      badgeText: 'STDERR',
      raw,
      message: trimmed
    };
  }

  return {
    id: index,
    level: 'INFO',
    raw,
    message: raw
  };
}

export const ResultsPanel: React.FC<ResultsPanelProps> = ({ 
  result, 
  onClear,
  onInsertLoggingDemo
}) => {
  const [selectedLevel, setSelectedLevel] = useState<LogLevel>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'formatted' | 'raw'>('formatted');
  const [copied, setCopied] = useState(false);

  // Parse all lines from stdout and stderr
  const parsedLines = useMemo(() => {
    if (!result) return [];
    const lines: ParsedLogLine[] = [];
    let idx = 0;

    if (result.stdout) {
      const stdoutLines = result.stdout.split(/\r?\n/);
      // If the last line is empty, don't include it if there are previous lines
      for (const line of stdoutLines) {
        if (line.length > 0 || stdoutLines.length === 1) {
          lines.push(parseLogLine(line, idx++, false));
        }
      }
    }

    if (result.stderr) {
      const stderrLines = result.stderr.split(/\r?\n/);
      for (const line of stderrLines) {
        if (line.length > 0 || stderrLines.length === 1) {
          lines.push(parseLogLine(line, idx++, true));
        }
      }
    }

    if (result.error && !result.stderr) {
      lines.push(parseLogLine(result.error, idx++, true));
    }

    return lines;
  }, [result]);

  // Compute counts per level
  const counts = useMemo(() => {
    const countsMap = {
      ALL: parsedLines.length,
      DEBUG: 0,
      INFO: 0,
      WARNING: 0,
      ERROR: 0,
      CRITICAL: 0,
      TRACEBACK: 0,
      SUCCESS: 0,
    };
    parsedLines.forEach(l => {
      if (l.level in countsMap) {
        countsMap[l.level]++;
      }
    });
    return countsMap;
  }, [parsedLines]);

  // Filter lines based on selected level and search query
  const filteredLines = useMemo(() => {
    return parsedLines.filter(line => {
      if (selectedLevel !== 'ALL') {
        if (selectedLevel === 'ERROR' && (line.level === 'ERROR' || line.level === 'CRITICAL' || line.level === 'TRACEBACK')) {
          // Include critical & traceback in error filter
        } else if (line.level !== selectedLevel) {
          return false;
        }
      }

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return line.raw.toLowerCase().includes(q);
      }

      return true;
    });
  }, [parsedLines, selectedLevel, searchQuery]);

  const handleCopy = () => {
    if (!result) return;
    const textToCopy = [result.stdout, result.stderr, result.error].filter(Boolean).join('\n');
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const renderBadge = (level: LogLevel, text?: string) => {
    switch (level) {
      case 'DEBUG':
        return (
          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-bold font-mono tracking-wider bg-sky-950/70 text-sky-400 border border-sky-800/40">
            {text || 'DEBUG'}
          </span>
        );
      case 'INFO':
        return (
          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-bold font-mono tracking-wider bg-indigo-950/70 text-indigo-400 border border-indigo-800/40">
            {text || 'INFO'}
          </span>
        );
      case 'WARNING':
        return (
          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-bold font-mono tracking-wider bg-amber-950/70 text-amber-400 border border-amber-800/40">
            {text || 'WARN'}
          </span>
        );
      case 'ERROR':
        return (
          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-bold font-mono tracking-wider bg-rose-950/80 text-rose-400 border border-rose-800/50">
            {text || 'ERROR'}
          </span>
        );
      case 'CRITICAL':
        return (
          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-black font-mono tracking-wider bg-red-900 text-red-200 border border-red-500 animate-pulse">
            {text || 'CRIT'}
          </span>
        );
      case 'TRACEBACK':
        return (
          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-bold font-mono tracking-wider bg-rose-950/60 text-rose-300 border border-rose-800/40">
            {text || 'TRACE'}
          </span>
        );
      case 'SUCCESS':
        return (
          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-bold font-mono tracking-wider bg-emerald-950/70 text-emerald-400 border border-emerald-800/40">
            {text || 'PASS'}
          </span>
        );
      default:
        return null;
    }
  };

  const getLineTextColor = (level: LogLevel) => {
    switch (level) {
      case 'DEBUG':
        return 'text-sky-300';
      case 'INFO':
        return 'text-slate-200';
      case 'WARNING':
        return 'text-amber-200';
      case 'ERROR':
        return 'text-rose-300 font-medium';
      case 'CRITICAL':
        return 'text-red-100 font-bold';
      case 'TRACEBACK':
        return 'text-rose-300 font-medium';
      case 'SUCCESS':
        return 'text-emerald-300 font-semibold';
      default:
        return 'text-slate-300';
    }
  };

  return (
    <div className="h-64 bg-[#0c0e14] border-t border-slate-800 flex flex-col text-slate-300 overflow-hidden shadow-2xl">
      {/* Top Header & Filter Bar */}
      <div className="h-10 bg-[#161922] border-b border-slate-800 flex items-center justify-between px-4 gap-2 flex-wrap sm:flex-nowrap">
        {/* Level Filters */}
        <div className="flex items-center space-x-1 overflow-x-auto py-1">
          <button
            onClick={() => setSelectedLevel('ALL')}
            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider transition-all flex items-center gap-1 ${
              selectedLevel === 'ALL'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <span>All</span>
            {counts.ALL > 0 && <span className="text-[9px] opacity-80 font-mono">({counts.ALL})</span>}
          </button>

          <button
            onClick={() => setSelectedLevel('DEBUG')}
            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider transition-all flex items-center gap-1 ${
              selectedLevel === 'DEBUG'
                ? 'bg-sky-600 text-white'
                : 'text-sky-400/80 hover:text-sky-300 hover:bg-sky-950/40'
            }`}
          >
            <span>Debug</span>
            {counts.DEBUG > 0 && <span className="text-[9px] font-mono">({counts.DEBUG})</span>}
          </button>

          <button
            onClick={() => setSelectedLevel('INFO')}
            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider transition-all flex items-center gap-1 ${
              selectedLevel === 'INFO'
                ? 'bg-indigo-600 text-white'
                : 'text-indigo-400/80 hover:text-indigo-300 hover:bg-indigo-950/40'
            }`}
          >
            <span>Info</span>
            {counts.INFO > 0 && <span className="text-[9px] font-mono">({counts.INFO})</span>}
          </button>

          <button
            onClick={() => setSelectedLevel('WARNING')}
            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider transition-all flex items-center gap-1 ${
              selectedLevel === 'WARNING'
                ? 'bg-amber-600 text-white'
                : 'text-amber-400/80 hover:text-amber-300 hover:bg-amber-950/40'
            }`}
          >
            <span>Warn</span>
            {counts.WARNING > 0 && <span className="text-[9px] font-mono">({counts.WARNING})</span>}
          </button>

          <button
            onClick={() => setSelectedLevel('ERROR')}
            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider transition-all flex items-center gap-1 ${
              selectedLevel === 'ERROR'
                ? 'bg-rose-600 text-white'
                : 'text-rose-400/80 hover:text-rose-300 hover:bg-rose-950/40'
            }`}
          >
            <span>Errors</span>
            {(counts.ERROR + counts.CRITICAL + counts.TRACEBACK) > 0 && (
              <span className="text-[9px] font-mono">({counts.ERROR + counts.CRITICAL + counts.TRACEBACK})</span>
            )}
          </button>
        </div>

        {/* Right Actions: Search, View Mode Toggle, Copy, Clear */}
        <div className="flex items-center gap-2">
          {/* Quick Search in Logs */}
          <div className="relative hidden md:flex items-center">
            <Search className="absolute left-2 w-3 h-3 text-slate-500" />
            <input
              type="text"
              placeholder="Filter logs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-[#0c0e14] border border-slate-800 rounded py-0.5 pl-6 pr-2 text-[10px] text-slate-200 focus:outline-none focus:border-indigo-500/50 w-28 lg:w-36 transition-all placeholder:text-slate-600"
            />
          </div>

          {/* View Mode Toggle */}
          <div className="flex bg-[#0c0e14] border border-slate-800 rounded p-0.5 text-[9px] font-mono">
            <button
              onClick={() => setViewMode('formatted')}
              className={`px-1.5 py-0.5 rounded transition-colors ${
                viewMode === 'formatted' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Formatted Color-Coded Log View"
            >
              Colors
            </button>
            <button
              onClick={() => setViewMode('raw')}
              className={`px-1.5 py-0.5 rounded transition-colors ${
                viewMode === 'raw' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Raw Monospace Terminal Output"
            >
              Raw
            </button>
          </div>

          {/* Performance Metrics: Execution time & Memory estimate */}
          {result && (
            <div className="flex items-center gap-2 px-2 py-0.5 rounded bg-[#0c0e14] border border-slate-800 text-[10px] font-mono shadow-inner">
              <div className="flex items-center gap-1 text-amber-400" title="Execution Time">
                <Zap className="w-3 h-3 text-amber-400 fill-amber-400/20" />
                <span>{result.executionTimeMs !== undefined ? `${result.executionTimeMs}ms` : '<1ms'}</span>
              </div>
              <div className="w-[1px] h-3 bg-slate-800" />
              <div className="flex items-center gap-1 text-sky-400" title="Estimated Peak Memory Usage">
                <Cpu className="w-3 h-3 text-sky-400" />
                <span>
                  {result.memoryKb 
                    ? result.memoryKb >= 1024 
                      ? `${(result.memoryKb / 1024).toFixed(1)} MB` 
                      : `${result.memoryKb} KB`
                    : '128 KB'}
                </span>
              </div>
            </div>
          )}

          {/* Status Indicator */}
          {result && (
            <div className="flex items-center gap-1.5 text-[10px] pl-1 font-bold uppercase tracking-wider">
              {result.success ? (
                <div className="flex items-center gap-1 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                  <span className="hidden sm:inline">Passed</span>
                </div>
              ) : (
                <div className="flex items-center gap-1 text-rose-400">
                  <AlertCircle className="w-3.5 h-3.5 text-rose-500" />
                  <span className="hidden sm:inline">Failed</span>
                </div>
              )}
            </div>
          )}

          {/* Copy Button */}
          {result && (
            <button
              onClick={handleCopy}
              className="p-1.5 hover:bg-slate-800 rounded transition-colors text-slate-400 hover:text-white"
              title="Copy Output"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          )}

          {/* Clear Button */}
          <button 
            onClick={onClear}
            className="p-1.5 hover:bg-slate-800 rounded transition-colors text-slate-500 hover:text-slate-200"
            title="Clear Console"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
      
      {/* Log Output Body */}
      <div className="flex-1 overflow-y-auto p-4 font-mono text-xs leading-relaxed select-text">
        {!result ? (
          <div className="flex flex-col h-full justify-between">
            <div className="flex items-center space-x-2">
              <span className="text-indigo-500 font-bold tracking-tighter">❯</span>
              <span className="animate-pulse w-2 h-4 bg-indigo-500/50"></span>
              <span className="text-slate-600 text-[11px] uppercase tracking-widest font-bold ml-2">
                Ready for execution — press 'Run' (Ctrl+Enter)
              </span>
            </div>

            {/* Quick Logging helper hint */}
            {onInsertLoggingDemo && (
              <div className="bg-[#161922]/50 border border-slate-800/80 rounded-xl p-3 max-w-md mt-4">
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-1.5 text-indigo-400 font-bold text-[11px]">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Python Logging Support</span>
                  </div>
                  <button
                    onClick={onInsertLoggingDemo}
                    className="text-[10px] text-indigo-400 hover:text-indigo-300 underline font-sans"
                  >
                    Insert Demo
                  </button>
                </div>
                <p className="text-[10px] text-slate-400 font-sans leading-normal">
                  Color-codes <code className="text-sky-300">DEBUG</code>, <code className="text-indigo-300">INFO</code>, <code className="text-amber-300">WARNING</code>, <code className="text-rose-300">ERROR</code> and tracebacks automatically.
                </p>
              </div>
            )}
          </div>
        ) : viewMode === 'raw' ? (
          /* Raw Terminal View */
          <div className="space-y-1">
            {result.stdout && (
              <div className="text-slate-300 whitespace-pre-wrap">{result.stdout}</div>
            )}
            {result.stderr && (
              <div className="text-rose-400 whitespace-pre-wrap">{result.stderr}</div>
            )}
            {result.error && !result.stderr && (
              <div className="text-rose-500 font-bold whitespace-pre-wrap">{result.error}</div>
            )}
            <div className="flex items-center mt-3 pt-2 border-t border-slate-800/50">
              <span className="text-indigo-500 mr-2 font-bold tracking-tighter">❯</span>
              <span className="animate-pulse w-2 h-4 bg-indigo-500"></span>
            </div>
          </div>
        ) : (
          /* Structured Color-Coded Log View */
          <div className="space-y-1">
            {filteredLines.length === 0 ? (
              <div className="py-6 text-center text-slate-600 text-xs font-sans">
                No logs match the filter '{selectedLevel}' {searchQuery && `with query "${searchQuery}"`}
              </div>
            ) : (
              filteredLines.map((line) => (
                <div 
                  key={line.id} 
                  className={`group flex items-start gap-2.5 py-0.5 px-1.5 rounded transition-colors hover:bg-[#161922]/80 ${
                    line.level === 'ERROR' || line.level === 'CRITICAL' ? 'bg-rose-950/20' : 
                    line.level === 'WARNING' ? 'bg-amber-950/15' : 
                    line.level === 'DEBUG' ? 'bg-sky-950/15' : ''
                  }`}
                >
                  {/* Line Index */}
                  <span className="text-[10px] text-slate-700 w-5 text-right select-none font-mono shrink-0 pt-0.5 group-hover:text-slate-500">
                    {line.id + 1}
                  </span>

                  {/* Level Badge */}
                  <div className="shrink-0 pt-0.5">
                    {renderBadge(line.level, line.badgeText)}
                  </div>

                  {/* Source Logger name if present */}
                  {line.source && (
                    <span className="text-[10px] text-slate-500 font-mono shrink-0 pt-0.5">
                      [{line.source}]
                    </span>
                  )}

                  {/* Message Content with Color Coding */}
                  <div className={`flex-1 whitespace-pre-wrap break-all ${getLineTextColor(line.level)}`}>
                    {line.message}
                  </div>
                </div>
              ))
            )}

            <div className="flex items-center mt-3 pt-2 border-t border-slate-800/50">
              <span className="text-indigo-500 mr-2 font-bold tracking-tighter">❯</span>
              <span className="animate-pulse w-2 h-4 bg-indigo-500"></span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
