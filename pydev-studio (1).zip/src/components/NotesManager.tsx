import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, where, orderBy, onSnapshot, addDoc, deleteDoc, doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { useAuth } from './AuthContext';
import { StickyNote, Plus, Trash2, Sparkles, Loader2, Save, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import axios from 'axios';

interface Note {
  id: string;
  title: string;
  content: string;
  userId: string;
}

export const NotesManager: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { user } = useAuth();
  const [notes, setNotes] = useState<Note[]>([]);
  const [activeNote, setActiveNote] = useState<Note | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEnhancing, setIsEnhancing] = useState(false);

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'notes'),
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const notesData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Note[];
      setNotes(notesData);
      setIsLoading(false);
    });

    return unsubscribe;
  }, [user]);

  const handleCreate = async () => {
    if (!user) return;
    const newNote = {
      title: 'Untitled Note',
      content: '',
      userId: user.uid,
      createdAt: serverTimestamp()
    };
    const docRef = await addDoc(collection(db, 'notes'), newNote);
    setActiveNote({ id: docRef.id, ...newNote });
  };

  const handleUpdate = async (id: string, updates: Partial<Note>) => {
    await updateDoc(doc(db, 'notes', id), updates);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this note?')) return;
    await deleteDoc(doc(db, 'notes', id));
    if (activeNote?.id === id) setActiveNote(null);
  };

  const handleEnhance = async () => {
    if (!activeNote || isEnhancing) return;
    setIsEnhancing(true);
    try {
      const res = await axios.post('/api/ai/suggest', {
        code: activeNote.content,
        context: 'This is a note. Please improve its clarity and organization. Return only the improved content.'
      });
      if (res.data.improvedCode) {
        handleUpdate(activeNote.id, { content: res.data.improvedCode });
        setActiveNote({ ...activeNote, content: res.data.improvedCode });
      }
    } catch (err) {
      console.error('Enhance failed', err);
    } finally {
      setIsEnhancing(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="fixed inset-y-0 right-0 w-[500px] bg-[#0c0e14] border-l border-slate-800 shadow-2xl flex flex-col z-50"
    >
      <div className="h-14 border-b border-slate-800 flex items-center justify-between px-6 bg-[#161922]">
        <div className="flex items-center gap-3 text-indigo-400">
          <StickyNote className="w-5 h-5" />
          <span className="font-bold uppercase tracking-widest text-xs">AI Notes Studio</span>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-slate-800 rounded-full transition-colors text-slate-500">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <div className="w-48 border-r border-slate-800 flex flex-col bg-[#0f1117]">
          <button 
            onClick={handleCreate}
            className="m-4 flex items-center justify-center gap-2 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-bold transition-all shadow-lg shadow-indigo-500/20"
          >
            <Plus className="w-4 h-4" />
            <span>New Note</span>
          </button>
          <div className="flex-1 overflow-y-auto px-2 space-y-1">
            {notes.map(note => (
              <button
                key={note.id}
                onClick={() => setActiveNote(note)}
                className={`w-full text-left px-3 py-2.5 rounded text-[11px] transition-all truncate ${
                  activeNote?.id === note.id ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20' : 'text-slate-400 hover:bg-slate-800'
                }`}
              >
                {note.title || 'Untitled'}
              </button>
            ))}
          </div>
        </div>

        {/* Editor */}
        <div className="flex-1 flex flex-col bg-[#0c0e14]">
          {activeNote ? (
            <>
              <div className="p-6 space-y-4 flex-1 flex flex-col overflow-hidden">
                <input
                  type="text"
                  value={activeNote.title}
                  onChange={(e) => {
                    const newTitle = e.target.value;
                    setActiveNote({ ...activeNote, title: newTitle });
                    handleUpdate(activeNote.id, { title: newTitle });
                  }}
                  className="bg-transparent text-xl font-bold text-slate-100 focus:outline-none w-full"
                  placeholder="Note Title"
                />
                <textarea
                  value={activeNote.content}
                  onChange={(e) => {
                    const newContent = e.target.value;
                    setActiveNote({ ...activeNote, content: newContent });
                    handleUpdate(activeNote.id, { content: newContent });
                  }}
                  className="flex-1 bg-transparent text-slate-300 resize-none focus:outline-none font-mono text-sm leading-relaxed"
                  placeholder="Start writing..."
                />
              </div>
              <div className="h-14 border-t border-slate-800 px-6 flex items-center justify-between bg-[#0f1117]">
                <button
                  onClick={handleEnhance}
                  disabled={isEnhancing || !activeNote.content}
                  className="flex items-center gap-2 px-4 py-2 bg-indigo-500/10 text-indigo-400 hover:bg-indigo-500/20 rounded-full text-xs font-bold transition-all disabled:opacity-50"
                >
                  {isEnhancing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                  <span>AI Enhance</span>
                </button>
                <button
                  onClick={() => handleDelete(activeNote.id)}
                  className="p-2 text-slate-600 hover:text-rose-400 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-slate-600 opacity-50">
              <StickyNote className="w-16 h-16 mb-4" />
              <p className="text-sm">Select or create a note</p>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};
