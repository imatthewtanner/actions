import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Sidebar } from './components/Sidebar';
import { EditorView } from './components/EditorView';
import { ResultsPanel } from './components/ResultsPanel';
import { AISidebar } from './components/AISidebar';
import { PackageManager } from './components/PackageManager';
import { NotesManager } from './components/NotesManager';
import { WorkspaceTools } from './components/WorkspaceTools';
import { LearningCenter } from './components/LearningCenter';
import { MapsExplorer } from './components/MapsExplorer';
import { GitHubSyncModal } from './components/GitHubSyncModal';
import { AuthProvider, useAuth } from './components/AuthContext';
import { INITIAL_FUNCTIONS } from './data';
import { FunctionSnippet, ExecutionResult, AISuggestion } from './types';
import { AnimatePresence } from 'motion/react';

const AppContent: React.FC = () => {
  const { user, login, logout } = useAuth();
  
  const [functions, setFunctions] = useState<FunctionSnippet[]>(() => {
    const saved = localStorage.getItem('pydev_functions');
    return saved ? JSON.parse(saved) : INITIAL_FUNCTIONS;
  });
  
  const [activeId, setActiveId] = useState<string>(functions[0]?.id || "");
  const [currentCode, setCurrentCode] = useState(functions[0]?.code || "");
  const [currentTests, setCurrentTests] = useState(functions[0]?.tests || "");
  
  const [executionResult, setExecutionResult] = useState<ExecutionResult | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  
  const [aiSuggestion, setAiSuggestion] = useState<AISuggestion | null>(null);
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);

  const [isPackagesOpen, setIsPackagesOpen] = useState(false);
  const [isNotesOpen, setIsNotesOpen] = useState(false);
  const [isWorkspaceOpen, setIsWorkspaceOpen] = useState(false);
  const [isLearningOpen, setIsLearningOpen] = useState(false);
  const [isMapsOpen, setIsMapsOpen] = useState(false);
  const [isGitHubOpen, setIsGitHubOpen] = useState(false);
  const [autoSaveStatus, setAutoSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');

  const activeFunction = functions.find(f => f.id === activeId) || functions[0];

  // Debounced auto-save effect for code and tests
  useEffect(() => {
    if (!activeId) return;

    setAutoSaveStatus('saving');

    const saveTimer = setTimeout(() => {
      setFunctions(prev => {
        const updated = prev.map(f => 
          f.id === activeId ? { ...f, code: currentCode, tests: currentTests } : f
        );
        localStorage.setItem('pydev_functions', JSON.stringify(updated));
        return updated;
      });
      setAutoSaveStatus('saved');

      const idleTimer = setTimeout(() => {
        setAutoSaveStatus('idle');
      }, 1500);

      return () => clearTimeout(idleTimer);
    }, 600);

    return () => clearTimeout(saveTimer);
  }, [currentCode, currentTests, activeId]);

  const handleSelect = (id: string) => {
    const updated = functions.map(f => 
      f.id === activeId ? { ...f, code: currentCode, tests: currentTests } : f
    );
    setFunctions(updated);
    localStorage.setItem('pydev_functions', JSON.stringify(updated));
    
    const next = updated.find(f => f.id === id);
    if (next) {
      setActiveId(id);
      setCurrentCode(next.code);
      setCurrentTests(next.tests);
      setExecutionResult(null);
    }
  };

  const handleNew = () => {
    const newFn: FunctionSnippet = {
      id: Date.now().toString(),
      name: "New Function",
      description: "A blank Python function",
      code: "def main():\n    print('Hello World')\n\nmain()",
      tests: "assert True\nprint('Tests passed')"
    };
    setFunctions([...functions, newFn]);
    setActiveId(newFn.id);
    setCurrentCode(newFn.code);
    setCurrentTests(newFn.tests);
    setExecutionResult(null);
  };

  const handleRun = async () => {
    setIsExecuting(true);
    try {
      const response = await axios.post('/api/execute', {
        code: currentCode,
        tests: currentTests
      });
      setExecutionResult(response.data);
    } catch (err: any) {
      setExecutionResult({
        success: false,
        stdout: "",
        stderr: err.response?.data?.error || err.message,
        error: "Execution Error"
      });
    } finally {
      setIsExecuting(false);
    }
  };

  const handleSuggest = async () => {
    setIsAiOpen(true);
    setIsGeneratingAi(true);
    try {
      const response = await axios.post('/api/ai/suggest', {
        code: currentCode,
        context: activeFunction.description
      });
      setAiSuggestion(response.data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const handleSave = () => {
    const updated = functions.map(f => 
      f.id === activeId ? { ...f, code: currentCode, tests: currentTests } : f
    );
    setFunctions(updated);
  };

  const handleReset = () => {
    setCurrentCode(activeFunction.code);
    setCurrentTests(activeFunction.tests);
  };

  const handleImportSnippets = (imported: FunctionSnippet[], merge: boolean) => {
    if (merge) {
      // Merge unique by name or ID
      const existingIds = new Set(functions.map(f => f.id));
      const newItems = imported.filter(item => !existingIds.has(item.id));
      const updated = [...functions, ...newItems];
      setFunctions(updated);
      if (imported.length > 0) {
        setActiveId(imported[0].id);
        setCurrentCode(imported[0].code);
        setCurrentTests(imported[0].tests);
      }
    } else {
      setFunctions(imported);
      if (imported.length > 0) {
        setActiveId(imported[0].id);
        setCurrentCode(imported[0].code);
        setCurrentTests(imported[0].tests);
      }
    }
  };

  const handleInsertLoggingDemo = () => {
    const loggingFn = functions.find(f => f.name.includes("Logging") || f.id === "4");
    if (loggingFn) {
      setActiveId(loggingFn.id);
      setCurrentCode(loggingFn.code);
      setCurrentTests(loggingFn.tests);
    } else {
      const demoCode = `import logging
import sys

# Configure logger format
logging.basicConfig(
    level=logging.DEBUG,
    format='%(levelname)s:%(name)s:%(message)s',
    stream=sys.stdout
)

logger = logging.getLogger("pydev.main")

logger.debug("Debug message: Initializing component")
logger.info("Info message: User session authenticated")
logger.warning("Warning message: Cache miss on key 'user_meta'")
logger.error("Error message: Database query timeout after 2000ms")

print("Standard print output from Python")
`;
      setCurrentCode(demoCode);
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#0f1117] text-slate-300 selection:bg-indigo-500/30">
      <Sidebar 
        functions={functions} 
        activeId={activeId} 
        onSelect={handleSelect} 
        onNew={handleNew} 
        onTogglePackages={() => {
          setIsPackagesOpen(!isPackagesOpen);
          setIsAiOpen(false);
          setIsNotesOpen(false);
        }}
        onToggleNotes={() => {
          setIsNotesOpen(!isNotesOpen);
          setIsAiOpen(false);
          setIsPackagesOpen(false);
        }}
        onToggleWorkspace={() => {
          setIsWorkspaceOpen(true);
        }}
        onToggleLearning={() => {
          setIsLearningOpen(!isLearningOpen);
          setIsAiOpen(false);
          setIsPackagesOpen(false);
          setIsNotesOpen(false);
          setIsMapsOpen(false);
        }}
        onToggleMaps={() => {
          setIsMapsOpen(!isMapsOpen);
          setIsAiOpen(false);
          setIsPackagesOpen(false);
          setIsNotesOpen(false);
          setIsLearningOpen(false);
        }}
        onToggleGitHub={() => {
          setIsGitHubOpen(true);
        }}
        user={user}
        onLogin={login}
        onLogout={logout}
      />
      
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="h-12 border-b border-slate-800 flex items-center justify-between px-4 bg-[#161922] shrink-0">
          <div className="flex items-center space-x-4">
            <div className="w-8 h-8 bg-indigo-600 rounded flex items-center justify-center font-bold text-white shadow-lg shadow-indigo-500/20">Py</div>
            <nav className="flex space-x-6 ml-6 text-sm font-medium">
              <span className="text-indigo-400 border-b-2 border-indigo-400 pb-3.5 mt-1 px-1">Editor</span>
              <span className="text-slate-500 hover:text-white cursor-pointer transition-colors">Debugger</span>
              <span className="text-slate-500 hover:text-white cursor-pointer transition-colors">Performance</span>
            </nav>
          </div>
          <div className="flex items-center gap-3">
             <div className="flex items-center gap-2 px-3 py-1 bg-[#1a1d27] rounded border border-slate-800">
                <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{activeFunction.name}</span>
             </div>
          </div>
        </header>

        <div className="flex-1 flex min-h-0 relative">
          <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
            <EditorView 
              code={currentCode}
              tests={currentTests}
              onCodeChange={(v) => setCurrentCode(v || '')}
              onTestsChange={(v) => setCurrentTests(v || '')}
              onRun={handleRun}
              onDebug={handleRun} 
              onSuggest={handleSuggest}
              onSave={handleSave}
              onReset={handleReset}
              isRunning={isExecuting}
              autoSaveStatus={autoSaveStatus}
            />
            <ResultsPanel 
              result={executionResult} 
              onClear={() => setExecutionResult(null)} 
              onInsertLoggingDemo={handleInsertLoggingDemo}
            />
          </div>

          <AnimatePresence mode="wait">
            {isAiOpen && (
              <AISidebar 
                key="ai-sidebar"
                suggestion={aiSuggestion}
                onClose={() => setIsAiOpen(false)}
                onApply={(code) => {
                  setCurrentCode(code);
                  setIsAiOpen(false);
                }}
                isGenerating={isGeneratingAi}
              />
            )}
            {isPackagesOpen && (
              <PackageManager 
                key="package-manager"
                onClose={() => setIsPackagesOpen(false)}
              />
            )}
            {isNotesOpen && (
              <NotesManager 
                key="notes-manager"
                onClose={() => setIsNotesOpen(false)}
              />
            )}
            {isWorkspaceOpen && (
              <WorkspaceTools 
                key="workspace-tools"
                onClose={() => setIsWorkspaceOpen(false)}
              />
            )}
            {isLearningOpen && (
              <LearningCenter 
                key="learning-center"
                onClose={() => setIsLearningOpen(false)}
              />
            )}
            {isMapsOpen && (
              <MapsExplorer
                key="maps-explorer"
                onClose={() => setIsMapsOpen(false)}
                onInsertCode={(codeSnippet) => {
                  setCurrentCode(prev => prev + '\n\n' + codeSnippet);
                  setIsMapsOpen(false);
                }}
              />
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* GitHub Sync Modal */}
      <GitHubSyncModal
        isOpen={isGitHubOpen}
        onClose={() => setIsGitHubOpen(false)}
        snippets={functions}
        onImportSnippets={handleImportSnippets}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
