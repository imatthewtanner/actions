import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Suppress benign ResizeObserver loop errors (triggered by Monaco editor / responsive layout resizing)
if (typeof window !== 'undefined') {
  const resizeObserverErrHandler = (e: ErrorEvent) => {
    if (
      e.message === 'ResizeObserver loop completed with undelivered notifications.' ||
      e.message === 'ResizeObserver loop limit exceeded' ||
      e.error?.message?.includes('ResizeObserver')
    ) {
      e.stopImmediatePropagation();
      e.preventDefault();
      return true;
    }
  };

  window.addEventListener('error', resizeObserverErrHandler);

  // Also catch unhandled promise rejections if any
  window.addEventListener('unhandledrejection', (e: PromiseRejectionEvent) => {
    if (e.reason?.message?.includes('ResizeObserver')) {
      e.preventDefault();
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
