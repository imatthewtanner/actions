import React from 'react';
import { Layout as LayoutIcon, Code2, Play, Bug, Sparkles, FolderCode, Save, Plus, Package, StickyNote, HardDrive, LogIn, LogOut, User as UserIcon, BookOpen, Compass, Github } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { FunctionSnippet } from '../types';
import { User } from 'firebase/auth';

interface SidebarProps {
  functions: FunctionSnippet[];
  activeId: string;
  onSelect: (id: string) => void;
  onNew: () => void;
  onTogglePackages: () => void;
  onToggleNotes: () => void;
  onToggleWorkspace: () => void;
  onToggleLearning: () => void;
  onToggleMaps: () => void;
  onToggleGitHub: () => void;
  user: User | null;
  onLogin: () => void;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  functions, 
  activeId, 
  onSelect, 
  onNew, 
  onTogglePackages,
  onToggleNotes,
  onToggleWorkspace,
  onToggleLearning,
  onToggleMaps,
  onToggleGitHub,
  user,
  onLogin,
  onLogout
}) => {
  return (
    <div className="w-60 bg-[#161922] border-r border-slate-800 flex flex-col h-full text-slate-400">
      <div className="p-4 uppercase text-[10px] font-bold text-slate-500 tracking-widest flex items-center justify-between">
        <span>Workspace</span>
        <button 
          onClick={onNew}
          className="p-1 hover:bg-slate-800 rounded transition-colors text-slate-500 hover:text-white"
          title="New Function"
        >
          <Plus className="w-3.5 h-3.5" />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto px-2 space-y-1">
        {functions.map((fn) => (
          <button
            key={fn.id}
            onClick={() => onSelect(fn.id)}
            className={`w-full group flex items-center px-2 py-1.5 rounded text-sm transition-all cursor-pointer ${
              activeId === fn.id 
                ? 'bg-indigo-500/10 text-slate-100 shadow-sm shadow-indigo-500/5' 
                : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className={`mr-2 transition-colors ${activeId === fn.id ? 'text-indigo-400' : 'text-slate-500 group-hover:text-slate-400'}`}>λ</span>
            <span className="truncate">{fn.name}</span>
          </button>
        ))}
        
        <div className="p-4 uppercase text-[10px] font-bold text-slate-500 tracking-widest mt-4">Features</div>
        <div className="px-2 space-y-1">
          <button 
            onClick={onToggleNotes}
            className="w-full group flex items-center px-2 py-1.5 rounded text-sm hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-all cursor-pointer"
          >
            <StickyNote className="w-3.5 h-3.5 mr-2 text-slate-500 group-hover:text-amber-400 transition-colors" />
            <span>AI Notes</span>
          </button>
          <button 
            onClick={onToggleWorkspace}
            className="w-full group flex items-center px-2 py-1.5 rounded text-sm hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-all cursor-pointer"
          >
            <HardDrive className="w-3.5 h-3.5 mr-2 text-slate-500 group-hover:text-blue-400 transition-colors" />
            <span>Drive Explorer</span>
          </button>
          <button 
            onClick={onToggleLearning}
            className="w-full group flex items-center px-2 py-1.5 rounded text-sm hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-all cursor-pointer"
          >
            <BookOpen className="w-3.5 h-3.5 mr-2 text-slate-500 group-hover:text-indigo-400 transition-colors" />
            <span>Learning Lab</span>
          </button>
          <button 
            onClick={onToggleMaps}
            className="w-full group flex items-center px-2 py-1.5 rounded text-sm hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-all cursor-pointer"
          >
            <Compass className="w-3.5 h-3.5 mr-2 text-slate-500 group-hover:text-emerald-400 transition-colors" />
            <span>Google Maps</span>
          </button>
          <button 
            onClick={onToggleGitHub}
            className="w-full group flex items-center px-2 py-1.5 rounded text-sm hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-all cursor-pointer"
          >
            <Github className="w-3.5 h-3.5 mr-2 text-slate-500 group-hover:text-indigo-400 transition-colors" />
            <span>Sync with GitHub</span>
          </button>
        </div>

        <div className="p-4 uppercase text-[10px] font-bold text-slate-500 tracking-widest mt-4">Environment</div>
        <div className="px-2 space-y-1">
          <button 
            onClick={onTogglePackages}
            className="w-full group flex items-center px-2 py-1.5 rounded text-sm hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-all cursor-pointer"
          >
            <Package className="w-3.5 h-3.5 mr-2 text-slate-500 group-hover:text-indigo-400 transition-colors" />
            <span>Packages</span>
          </button>
          <div className="flex items-center px-2 py-1.5 text-[11px] text-slate-500">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-2"></div>
            Python 3.11
          </div>
        </div>
      </div>

      {/* Auth Section */}
      <div className="p-4 bg-[#0f1117] border-t border-slate-800">
        {user ? (
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 overflow-hidden">
              <img src={user.photoURL || ''} className="w-8 h-8 rounded-full border border-slate-700" alt="" />
              <div className="flex-1 min-w-0">
                <p className="text-[11px] font-bold text-slate-200 truncate">{user.displayName}</p>
                <p className="text-[9px] text-slate-500 truncate">{user.email}</p>
              </div>
            </div>
            <button onClick={onLogout} className="p-1.5 hover:bg-slate-800 rounded transition-colors text-slate-500 hover:text-rose-400" title="Sign Out">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <button 
            onClick={onLogin}
            className="w-full flex items-center justify-center gap-2 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-bold transition-all shadow-lg shadow-indigo-500/20"
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>Sign In</span>
          </button>
        )}
      </div>
    </div>
  );
};
