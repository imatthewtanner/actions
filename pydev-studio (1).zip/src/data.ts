import { FunctionSnippet } from "./types";

export const INITIAL_FUNCTIONS: FunctionSnippet[] = [
  {
    id: "1",
    name: "Fibonacci Sequence",
    description: "Generate the nth Fibonacci number using recursion with memoization.",
    code: `def fibonacci(n, memo={}):
    if n in memo:
        return memo[n]
    if n <= 1:
        return n
    memo[n] = fibonacci(n - 1, memo) + fibonacci(n - 2, memo)
    return memo[n]

# Example usage
print(f"Fibonacci(10): {fibonacci(10)}")`,
    tests: `assert fibonacci(0) == 0
assert fibonacci(1) == 1
assert fibonacci(10) == 55
print("All tests passed!")`
  },
  {
    id: "2",
    name: "Data Processor",
    description: "A function to process a list of dictionaries and filter based on criteria.",
    code: `def process_data(data, threshold):
    """Filters data where value is above threshold."""
    return [item for item in data if item.get('value', 0) > threshold]

data = [
    {'name': 'A', 'value': 10},
    {'name': 'B', 'value': 20},
    {'name': 'C', 'value': 5}
]
print(f"Processed: {process_data(data, 8)}")`,
    tests: `data = [{'value': 10}, {'value': 5}]
assert len(process_data(data, 7)) == 1
assert process_data(data, 15) == []
print("All tests passed!")`
  },
  {
    id: "3",
    name: "Geo Distance (Haversine)",
    description: "Calculate great-circle distance between two GPS coordinate points on Earth in kilometers.",
    code: `import math

def haversine_distance(lat1, lon1, lat2, lon2):
    """Calculates distance in km between two GPS coordinates."""
    R = 6371.0  # Earth radius in kilometers
    
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)
    
    a = math.sin(delta_phi / 2)**2 + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    
    return round(R * c, 2)

# San Francisco (37.7749, -122.4194) to Mountain View (37.4220, -122.0841)
distance_km = haversine_distance(37.7749, -122.4194, 37.4220, -122.0841)
print(f"Distance: {distance_km} km")`,
    tests: `dist = haversine_distance(37.7749, -122.4194, 37.4220, -122.0841)
assert 45.0 <= dist <= 60.0, f"Expected ~50km, got {dist}"
print("All geo tests passed!")`
  },
  {
    id: "4",
    name: "Logging & Diagnostics",
    description: "Demonstrates Python's logging module across DEBUG, INFO, WARNING, and ERROR levels with color-coded terminal parsing.",
    code: `import logging
import sys

# Configure Python logging format
logging.basicConfig(
    level=logging.DEBUG,
    format='%(levelname)s:%(name)s:%(message)s',
    stream=sys.stdout
)

logger = logging.getLogger("pydev.analytics")

def calculate_analytics(payload):
    logger.debug(f"Received payload with {len(payload)} records")
    
    if not payload:
        logger.warning("Payload is empty, returning default metrics")
        return {"count": 0, "sum": 0, "avg": 0}
        
    logger.info(f"Processing data batch for customer analytics...")
    
    values = []
    for item in payload:
        val = item.get("value")
        if val is None:
            logger.error(f"Malformed record detected: {item} (missing 'value')")
        else:
            logger.debug(f"Valid data point: {val}")
            values.append(val)
            
    total = sum(values)
    avg = total / len(values) if values else 0
    logger.info(f"Computation complete: sum={total}, avg={avg:.2f}")
    return {"count": len(values), "sum": total, "avg": avg}

# Sample Execution
sample_data = [
    {"id": 1, "value": 45.5},
    {"id": 2, "value": 82.0},
    {"id": 3, "value": None},
    {"id": 4, "value": 110.2}
]

result = calculate_analytics(sample_data)
print(f"Final Result: {result}")`,
    tests: `data = [{"value": 10}, {"value": 20}]
res = calculate_analytics(data)
assert res["sum"] == 30
assert res["count"] == 2
print("All logging diagnostic tests passed!")`
  }
];
