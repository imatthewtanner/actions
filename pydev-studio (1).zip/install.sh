#!/usr/bin/env bash

# ==============================================================================
# PyDev Studio - Automated Installer & Environment Setup Script
# ==============================================================================

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}======================================================${NC}"
echo -e "${BLUE}        🚀 Initializing PyDev Studio Setup            ${NC}"
echo -e "${BLUE}======================================================${NC}"
echo ""

# 1. Check Node.js and NPM
echo -e "${YELLOW}[1/5] Checking Node.js and NPM...${NC}"
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js is not installed. Please install Node.js (v18+) first.${NC}"
    exit 1
fi

NODE_VERSION=$(node -v)
echo -e "${GREEN}✓ Node.js found: ${NODE_VERSION}${NC}"

if ! command -v npm &> /dev/null; then
    echo -e "${RED}❌ npm is not installed.${NC}"
    exit 1
fi
echo -e "${GREEN}✓ npm found: $(npm -v)${NC}"

# 2. Check Python 3 and Pip
echo ""
echo -e "${YELLOW}[2/5] Checking Python 3 and Pip environment...${NC}"
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python 3 is not installed. Please install Python 3.9+ to enable code execution.${NC}"
    exit 1
fi

PYTHON_VERSION=$(python3 --version)
echo -e "${GREEN}✓ Python runtime found: ${PYTHON_VERSION}${NC}"

# 3. Install Node.js Dependencies
echo ""
echo -e "${YELLOW}[3/5] Installing application dependencies via npm...${NC}"
npm install --silent
echo -e "${GREEN}✓ Node dependencies successfully installed.${NC}"

# 4. Build Production Bundle
echo ""
echo -e "${YELLOW}[4/5] Compiling production build...${NC}"
npm run build
echo -e "${GREEN}✓ Application build succeeded in /dist.${NC}"

# 5. Create Standalone Launch Script
echo ""
echo -e "${YELLOW}[5/5] Generating launcher executable...${NC}"
cat << 'EOF' > run.sh
#!/usr/bin/env bash
echo "Starting PyDev Studio on http://localhost:3000..."
npm start
EOF
chmod +x run.sh

echo ""
echo -e "${GREEN}======================================================${NC}"
echo -e "${GREEN}     🎉 PyDev Studio Installation Complete!           ${NC}"
echo -e "${GREEN}======================================================${NC}"
echo ""
echo -e "To start PyDev Studio:"
echo -e "  ${BLUE}./run.sh${NC}   or   ${BLUE}npm start${NC}"
echo ""
echo -e "For active development with hot-reload:"
echo -e "  ${BLUE}npm run dev${NC}"
echo ""
echo -e "Open your browser at: ${BLUE}http://localhost:3000${NC}"
echo ""
