@echo off
REM ==============================================================================
REM PyDev Studio - Windows Installer Script
REM ==============================================================================

echo ======================================================
echo         Initializing PyDev Studio Setup
echo ======================================================
echo.

echo [1/4] Checking Node.js and npm...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed. Please install Node.js 18+ from https://nodejs.org
    pause
    exit /b 1
)
node -v

echo.
echo [2/4] Checking Python 3...
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [WARNING] Python was not found in PATH. Code execution requires Python 3.
) else (
    python --version
)

echo.
echo [3/4] Installing NPM packages...
call npm install

echo.
echo [4/4] Building production application...
call npm run build

echo.
echo ======================================================
echo      PyDev Studio Installation Complete!
echo ======================================================
echo.
echo To start PyDev Studio, run:
echo    npm start
echo.
echo Then open your browser at: http://localhost:3000
echo.
pause
