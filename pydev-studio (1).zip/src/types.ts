export interface ExecutionResult {
  success: boolean;
  stdout: string;
  stderr: string;
  error: string | null;
  executionTimeMs?: number;
  memoryKb?: number;
}

export interface AISuggestion {
  suggestions: string[];
  improvedCode: string;
}

export interface FunctionSnippet {
  id: string;
  name: string;
  code: string;
  tests: string;
  description: string;
}

export interface PythonPackage {
  name: string;
  version: string;
}
