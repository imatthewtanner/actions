import React, { useState, useEffect } from 'react';
import Editor from '@monaco-editor/react';
import { Play, Bug, Sparkles, Save, RotateCcw, Maximize2, Minimize2, Check } from 'lucide-react';
import { motion } from 'motion/react';

interface EditorViewProps {
  code: string;
  tests: string;
  onCodeChange: (value: string | undefined) => void;
  onTestsChange: (value: string | undefined) => void;
  onRun: () => void;
  onDebug: () => void;
  onSuggest: () => void;
  onSave: () => void;
  onReset: () => void;
  isRunning: boolean;
  autoSaveStatus?: 'saved' | 'saving' | 'idle';
}

export const EditorView: React.FC<EditorViewProps> = ({
  code,
  tests,
  onCodeChange,
  onTestsChange,
  onRun,
  onDebug,
  onSuggest,
  onSave,
  onReset,
  isRunning,
  autoSaveStatus = 'idle'
}) => {
  const [isMaximized, setIsMaximized] = useState(false);

  // Allow Esc key to exit maximized mode
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isMaximized) {
        setIsMaximized(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isMaximized]);

  return (
    <div className={`flex flex-col bg-[#0f1117] transition-all ${
      isMaximized 
        ? 'fixed inset-0 z-50 w-screen h-screen' 
        : 'h-full w-full'
    }`}>
      <div className="h-10 border-b border-slate-800 flex items-center justify-between px-4 bg-[#1a1d27] shrink-0">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-[10px] font-mono text-slate-400">
            <span className="text-indigo-400">project</span> / <span className="text-indigo-400">src</span> / main.py
          </div>
          <div className="h-3 w-[1px] bg-slate-800"></div>
          <button 
            onClick={onSave}
            className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-slate-500 hover:text-white transition-colors"
          >
            <Save className="w-3 h-3" />
            Save
          </button>
          <button 
            onClick={onReset}
            className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-slate-500 hover:text-white transition-colors"
          >
            <RotateCcw className="w-3 h-3" />
            Reset
          </button>

          {/* Auto-save Indicator */}
          {autoSaveStatus !== 'idle' && (
            <div className="flex items-center gap-1 text-[9px] font-mono text-slate-500">
              <span className={`w-1.5 h-1.5 rounded-full ${autoSaveStatus === 'saving' ? 'bg-amber-400 animate-pulse' : 'bg-emerald-400'}`} />
              <span className="capitalize">{autoSaveStatus}</span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          {isMaximized && (
            <span className="hidden sm:inline-block px-2 py-0.5 text-[9px] font-mono uppercase tracking-wider text-indigo-300 bg-indigo-950/60 border border-indigo-800/40 rounded">
              Distraction-Free Mode (Esc)
            </span>
          )}

          <button
            onClick={() => setIsMaximized(!isMaximized)}
            className={`p-1.5 rounded border text-[10px] font-bold uppercase tracking-widest transition-all flex items-center gap-1 cursor-pointer ${
              isMaximized
                ? 'bg-indigo-600 border-indigo-500 text-white shadow-sm'
                : 'bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-white border-slate-700/60'
            }`}
            title={isMaximized ? "Exit Fullscreen (Esc)" : "Maximize Code Editor (Distraction-Free)"}
          >
            {isMaximized ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            <span className="hidden md:inline">{isMaximized ? 'Minimize' : 'Maximize'}</span>
          </button>

          <div className="h-3 w-[1px] bg-slate-800 mx-1"></div>

          <button
            onClick={onSuggest}
            className="flex items-center gap-2 px-3 py-1 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 text-[10px] font-bold uppercase tracking-widest rounded border border-indigo-500/20 transition-all cursor-pointer"
          >
            <Sparkles className="w-3 h-3" />
            AI Assist
          </button>
          <button
            onClick={onDebug}
            className="flex items-center gap-2 px-3 py-1 bg-slate-800/50 hover:bg-slate-800 text-slate-300 text-[10px] font-bold uppercase tracking-widest rounded border border-slate-700 transition-all cursor-pointer"
          >
            <Bug className="w-3 h-3" />
            Debug
          </button>
          <button
            onClick={onRun}
            disabled={isRunning}
            className={`flex items-center gap-2 px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 disabled:bg-emerald-500/50 text-emerald-950 text-[10px] font-black uppercase tracking-widest rounded transition-all shadow-lg shadow-emerald-500/10 cursor-pointer ${isRunning ? 'animate-pulse' : ''}`}
          >
            <Play className={`w-3 h-3 ${isRunning ? 'fill-emerald-950' : ''}`} />
            {isRunning ? 'Running' : 'Run Tests'}
          </button>
        </div>
      </div>
      
      <div className="flex-1 flex flex-col min-h-0 relative">
        <div className="flex-1 flex flex-col min-h-0">
          <div className="px-4 py-1.5 bg-[#161922] text-[9px] uppercase tracking-[0.2em] font-black text-slate-500 border-b border-slate-800 flex items-center justify-between">
            <span>Source Code</span>
            <span className="font-mono text-[9px] text-slate-600 lowercase">{code.split('\n').length} lines</span>
          </div>
          <div className="flex-1 min-h-0 bg-[#0f1117]">
            <Editor
              height="100%"
              defaultLanguage="python"
              theme="vs-dark"
              value={code}
              onChange={onCodeChange}
              options={{
                minimap: { enabled: false },
                fontSize: 13,
                lineHeight: 22,
                fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
                scrollBeyondLastLine: false,
                padding: { top: 16 },
                automaticLayout: true,
              }}
            />
          </div>
        </div>
        <div className="h-1/3 border-t border-slate-800 flex flex-col min-h-0">
          <div className="px-4 py-1.5 bg-[#161922] text-[9px] uppercase tracking-[0.2em] font-black text-slate-500 border-b border-slate-800 flex items-center justify-between">
            <span>Test Suite</span>
            <span className="font-mono text-[9px] text-slate-600 lowercase">{tests.split('\n').length} lines</span>
          </div>
          <div className="flex-1 min-h-0 bg-[#0f1117]">
            <Editor
              height="100%"
              defaultLanguage="python"
              theme="vs-dark"
              value={tests}
              onChange={onTestsChange}
              options={{
                minimap: { enabled: false },
                fontSize: 12,
                lineHeight: 20,
                fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
                scrollBeyondLastLine: false,
                padding: { top: 12 },
                automaticLayout: true,
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
