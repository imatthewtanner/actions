import React, { useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { HardDrive, Users, Folder, File, Loader2, Search, ExternalLink, User as UserIcon, Mail, Phone, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const WorkspaceTools: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { accessToken, login, user } = useAuth();
  const [activeTab, setActiveTab] = useState<'drive' | 'contacts'>('drive');
  const [driveFiles, setDriveFiles] = useState<any[]>([]);
  const [contacts, setContacts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchDriveFiles = async () => {
    if (!accessToken) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('https://www.googleapis.com/drive/v3/files?pageSize=15&fields=files(id,name,mimeType,webViewLink)', {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error.message);
      setDriveFiles(data.files || []);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchContacts = async () => {
    if (!accessToken) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('https://people.googleapis.com/v1/people/me/connections?personFields=names,emailAddresses,phoneNumbers&pageSize=20', {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error.message);
      setContacts(data.connections || []);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'drive') fetchDriveFiles();
    else fetchContacts();
  }, [activeTab, accessToken]);

  if (!user || !accessToken) {
    return (
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-[#161922] p-8 rounded-2xl border border-slate-800 shadow-2xl max-w-md w-full text-center">
          <div className="w-16 h-16 bg-indigo-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <HardDrive className="w-8 h-8 text-indigo-400" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">Connect Google Workspace</h2>
          <p className="text-slate-400 mb-8 text-sm leading-relaxed">
            Sign in with Google to access your Drive files and Contacts directly within the studio.
          </p>
          <button 
            onClick={login}
            className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-3"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-5 h-5 bg-white p-0.5 rounded" alt="" />
            Continue with Google
          </button>
          <button onClick={onClose} className="mt-4 text-slate-500 hover:text-white text-xs font-medium uppercase tracking-widest">Cancel</button>
        </motion.div>
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="fixed inset-4 md:inset-20 lg:inset-32 bg-[#0c0e14] border border-slate-800 rounded-2xl shadow-2xl flex flex-col z-50 overflow-hidden"
    >
      <div className="h-16 border-b border-slate-800 flex items-center justify-between px-8 bg-[#161922]">
        <div className="flex space-x-8">
          <button 
            onClick={() => setActiveTab('drive')}
            className={`flex items-center gap-2 text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'drive' ? 'text-indigo-400' : 'text-slate-500 hover:text-slate-300'}`}
          >
            <HardDrive className="w-4 h-4" />
            <span>Google Drive</span>
          </button>
          <button 
            onClick={() => setActiveTab('contacts')}
            className={`flex items-center gap-2 text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'contacts' ? 'text-indigo-400' : 'text-slate-500 hover:text-slate-300'}`}
          >
            <Users className="w-4 h-4" />
            <span>Contacts</span>
          </button>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-slate-800 rounded-full text-slate-500">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-8">
        {loading ? (
          <div className="h-full flex flex-col items-center justify-center opacity-50 space-y-4">
            <Loader2 className="w-8 h-8 animate-spin text-indigo-500" />
            <span className="text-[10px] uppercase tracking-widest font-bold text-slate-500">Accessing Google Cloud</span>
          </div>
        ) : error ? (
          <div className="h-full flex flex-col items-center justify-center text-rose-400 space-y-4">
            <p className="text-sm font-medium">{error}</p>
            <button onClick={activeTab === 'drive' ? fetchDriveFiles : fetchContacts} className="px-4 py-2 bg-rose-500/10 rounded-lg text-xs font-bold border border-rose-500/20">Retry Connection</button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {activeTab === 'drive' ? (
              driveFiles.map(file => (
                <a 
                  key={file.id} 
                  href={file.webViewLink} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="group bg-[#161922] p-4 rounded-xl border border-slate-800 hover:border-indigo-500/30 transition-all flex items-start gap-4"
                >
                  <div className="p-2 bg-slate-800 rounded-lg group-hover:bg-indigo-500/10 transition-colors">
                    {file.mimeType.includes('folder') ? <Folder className="w-5 h-5 text-amber-400" /> : <File className="w-5 h-5 text-blue-400" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-xs font-bold text-slate-200 truncate mb-1">{file.name}</h3>
                    <p className="text-[10px] text-slate-500 truncate">{file.mimeType.split('.').pop()}</p>
                  </div>
                  <ExternalLink className="w-3.5 h-3.5 text-slate-700 group-hover:text-slate-500" />
                </a>
              ))
            ) : (
              contacts.map(person => (
                <div key={person.resourceName} className="bg-[#161922] p-4 rounded-xl border border-slate-800 flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-indigo-400 font-bold uppercase text-xs">
                    {person.names?.[0]?.displayName?.charAt(0) || <UserIcon className="w-5 h-5" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-xs font-bold text-slate-200 truncate">{person.names?.[0]?.displayName || 'Unnamed'}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <Mail className="w-3 h-3 text-slate-600" />
                      <p className="text-[10px] text-slate-500 truncate">{person.emailAddresses?.[0]?.value || 'No email'}</p>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
};

const X = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
);
